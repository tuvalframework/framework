import { CGImage } from '@tuval/cg';
import { int, byte } from '@tuval/core';
export declare class ColorThief {
    GetColor(sourceImage: CGImage, quality?: number): number[];
    GetPalette(sourceImage: CGImage, colorCount?: int, quality?: int): byte[][];
    GetColorFromUrl(imageUrl: any, callback: any, quality: any): void;
    GetImageData(imageUrl: any, callback: any): void;
    GetColorAsync(imageUrl: any, callback: any, quality: any): void;
}
