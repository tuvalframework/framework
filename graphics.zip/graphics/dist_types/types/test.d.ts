import { TBuffer } from '@tuval/core';
export declare class Struct extends TBuffer {
}
export declare class POINT extends Struct {
    get X(): number;
    set X(value: number);
    get Y(): number;
    set Y(value: number);
}
