import { int } from '@tuval/core';
import { GUIComponent } from "./GUIComponent";
import { SketchGraphics } from '../drawing/sketch/SketchGraphics';
import { IMouseEventService } from '../services/IMouseEventService';
export declare class ToolbarComponent extends GUIComponent {
    private components;
    constructor(x: number, y: number, w: number);
    draw(tg: SketchGraphics): void;
    add(type: any, params: any): void;
    addButton(evetService: IMouseEventService, name: string, trigger: Function, height?: int): void;
    addRadioButtons(options: any, trigger: Function, defaultOption: any): void;
}
