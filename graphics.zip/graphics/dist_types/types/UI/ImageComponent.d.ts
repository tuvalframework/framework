import { LabelComponent } from "./LabelComponent";
import { SketchGraphics } from "../drawing/sketch/SketchGraphics";
export declare class ImageComponent extends LabelComponent {
    private image;
    constructor(x: number, y: number, w: number, h: number, params: any);
    draw(tg: SketchGraphics): void;
}
