import { GUIComponent } from "./GUIComponent";
import { SketchGraphics } from "../drawing/sketch/SketchGraphics";
export declare class LabelComponent extends GUIComponent {
    private x1;
    private x2;
    private y2;
    private textColor;
    constructor(x: number, y: number, w: number, h: number, params: any);
    draw(tg: SketchGraphics): void;
}
