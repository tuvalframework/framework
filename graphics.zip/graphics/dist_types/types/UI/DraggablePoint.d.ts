import { CGPoint } from '@tuval/cg';
import { int, ICursorService } from '@tuval/core';
import { float } from '@tuval/core';
import { SketchGraphics } from '../drawing/sketch/SketchGraphics';
export declare class DraggablePoint extends CGPoint {
    private color;
    private cursorService;
    private animation;
    private selected;
    private dragging;
    private enter;
    private mouseX;
    private mouseY;
    private pmouseX;
    private pmouseY;
    constructor(x: float, y: float, cursorService?: ICursorService);
    draw(tg: SketchGraphics): void;
    private mouseover;
    onMouseDown(): void;
    onMouseMove(/* evt: MouseEvent */ x: int, y: int, prevX: int, prevY: int): void;
    private mouseenter;
    private mouseout;
    onMouseUp(): void;
    move(): void;
}
