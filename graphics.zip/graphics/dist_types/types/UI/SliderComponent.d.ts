import { GUIComponent } from "./GUIComponent";
import { SketchGraphics } from "../drawing/sketch/SketchGraphics";
export declare class SliderComponent extends GUIComponent {
    private ballR;
    private ballD;
    private x2;
    private fill;
    private stroke;
    private min;
    private max;
    private val;
    private decimalPlaces;
    private bx;
    private hideVal;
    constructor(x: number, y: number, w: number, h: number, params: any);
    draw(tg: SketchGraphics): void;
    protected mouseOver(): boolean;
    protected mousePressed(): true | undefined;
    protected mouseDragged(): true | undefined;
    setValue(v: number): void;
}
