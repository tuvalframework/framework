import { ButtonComponent } from "./ButtonComponent";
import { SketchGraphics } from "../drawing/sketch/SketchGraphics";
export declare class CheckboxComponent extends ButtonComponent {
    private box;
    private bx;
    private by;
    checked: boolean;
    constructor(x: number, y: number, w: number, h: number, params: any);
    trigger(): void;
    protected mousePressed(): void;
    draw(tg: SketchGraphics): void;
}
