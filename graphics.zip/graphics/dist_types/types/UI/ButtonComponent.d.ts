import { CGColor } from '@tuval/cg';
import { GUIComponent } from "./GUIComponent";
import { SketchGraphics } from '../drawing/sketch/SketchGraphics';
import { IMouseEventService } from "../services/IMouseEventService";
export declare class ButtonComponent extends GUIComponent {
    protected defaultCol: CGColor;
    protected highlightCol: CGColor;
    constructor(eventService: IMouseEventService, x: number, y: number, w: number, h: number, params: any);
    draw(tg: SketchGraphics): void;
    private drawFilled;
    private makeFilled;
}
