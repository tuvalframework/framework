import { ButtonComponent } from "./ButtonComponent";
import { SketchGraphics } from "../drawing/sketch/SketchGraphics";
export declare class RadioButtonComponent extends ButtonComponent {
    r: number;
    cx: number;
    cy: number;
    marked: boolean;
    constructor(x: number, y: number, w: number, h: number, name: string, trigger: Function);
    draw(tg: SketchGraphics): void;
}
