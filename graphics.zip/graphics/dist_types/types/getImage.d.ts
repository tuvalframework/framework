export declare function getImage(arg: string | HTMLImageElement | ImageData, callback: Function): void;
