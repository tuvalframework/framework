declare class CMap {
    vboxes: any;
    constructor();
    push(vbox: any): void;
    palette(): any;
    size(): any;
    map(color: any): any;
    nearest(color: any): any;
    forcebw(): void;
}
export declare function quantize(pixels: any, maxcolors: any): false | CMap;
export {};
