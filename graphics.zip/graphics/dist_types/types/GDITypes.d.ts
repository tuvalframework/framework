export declare const GraphicTypes: {
    Bitmap: symbol;
    GdipEncoderParameter: symbol;
    Region: symbol;
    Image: symbol;
    ImageList: symbol;
    StringFormat: symbol;
    Font: symbol;
    Graphics: symbol;
    GraphicsBase: symbol;
    ColorMatrix: symbol;
    SolidBrush: symbol;
    Brush: symbol;
    LinearGradientBrush: symbol;
    PathGradientBrush: symbol;
    GraphicsPath: symbol;
    HatchBrush: symbol;
    Icon: symbol;
    Pen: symbol;
    TextureBrush: symbol;
    RadialGradientBrush: symbol;
    PaintEventArgs: symbol;
    Imaging: {
        ImageAttributes: symbol;
        FrameDimension: symbol;
    };
    geom: {
        Shape: symbol;
        Point2D: symbol;
        Line2D: symbol;
        Rectangle2D: symbol;
        AffineTransform: symbol;
    };
    Application: symbol;
    Tgx: {
        graphics: {
            Color: symbol;
            Pixmap: symbol;
        };
        files: {
            FileHandle: symbol;
        };
        backend: {
            preloader: {
                Preloader: symbol;
            };
        };
        utils: {
            ObjectMap: {
                Keys: symbol;
                Values: symbol;
                Entries: symbol;
                MapIterator: symbol;
                ObjectMap: symbol;
                Entry: symbol;
            };
            IntArray: symbol;
            Array: symbol;
        };
    };
};
