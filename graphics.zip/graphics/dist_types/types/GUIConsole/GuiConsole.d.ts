import { CGRectangle } from "@tuval/cg";
import { TextConsole, int, LazyValue } from '@tuval/core';
import { Brush } from "../drawing/Brush";
import { Pen } from "../drawing/Pen";
import { GuiTVC } from "./GuiTVC";
type Lazy<T> = T | LazyValue<T>;
export declare class GuiConsole<T extends GuiTVC> extends TextConsole<T> {
    CreateTVC(canvas: HTMLCanvasElement, options: any): T;
    DrawLine(pen: Pen | LazyValue<Pen>, x1: int | LazyValue<int>, y1: int | LazyValue<int>, x2: int | LazyValue<int>, y2: int | LazyValue<int>): void;
    DrawRectangle(pen: Pen | LazyValue<Pen>, rect: CGRectangle | LazyValue<CGRectangle>): void;
    FillRectangle(brush: Brush | LazyValue<Pen>, rect: CGRectangle | LazyValue<CGRectangle>): void;
    DrawEllipse(pen: Pen | LazyValue<Pen>, rect: CGRectangle | LazyValue<CGRectangle>): void;
    FillEllipse(brush: Brush | LazyValue<Pen>, rect: CGRectangle | LazyValue<CGRectangle>): void;
    /**
     * Clear an area of the current screen
     * @param ink The index of the color in the palette to clear with
     * @param x The horizontal coordinate of the top-left pixel of the rectangle to clear
     * @param y The vertical coordinate of the top-left pixel of the rectangle to clear
     * @param width The horizontal coordinate of the bottom-right pixel of the rectangle to clear
     * @param height The vertical coordinate of the bottom-right pixel of the rectangle to clear
     */
    Cls(ink: Lazy<int>, x: Lazy<int>, y: Lazy<int>, width: Lazy<int>, height: Lazy<int>): void;
    /**
     * Draw a line with the current Ink from the last graphical position
     * @param x The horizontal coordinate of the point
     * @param y  The vertical coordinate of the point
     * @param width width of line
     * @param height height of line
     */
    Draw(x: Lazy<int>, y: Lazy<int>, width: Lazy<int>, height: Lazy<int>): void;
    /**
     * Draw an ellipse with the current Ink in the current screen
     * @param x The horizontal coordinate of the center of the ellipse
     * @param y The vertical coordinate of the center of the ellipse
     * @param xRadius The horizontal radius in pixels
     * @param yRadius The vertical radius in pixels
     */
    Ellipse(x: Lazy<int>, y: Lazy<int>, xRadius: Lazy<int>, yRadius: Lazy<int>): void;
    /**
     * Mouse Commands
     */
    get MouseX(): int;
    get MouseY(): int;
    get MouseKey(): int;
    HideMouse(): void;
    ShowMouse(): void;
    /**
     * Screen Commands
     */
    /**
     * Open a new screen
     * @param index The index of the screen to open. Any existing screen will be replaced by the new one
     * @param width The width of the screen in pixels
     * @param height The height of the screen in pixels
     * @param numberOfColor The number of colors of the palette (optional)
     * @param pixelMode Lowres, Hires, Laced or any combination
     * @param columns Number of columns in the text window associated with the screen
     * @param lines Number of lines in the text window associated with the screen
     * @param tags$ List of eventual tags
     */
    ScreenOpen(index: LazyValue<int>, width: LazyValue<int>, height: LazyValue<int>, numberOfColor?: LazyValue<int>, pixelMode?: LazyValue<int>, columns?: LazyValue<int>, lines?: LazyValue<int>, tags$?: LazyValue<int>): void;
    /**
     * Destroys the current screen or a given screen
     * @param index The index of the screen to destroy, if ommited will destroy the current screen
     */
    ScreenClose(index: LazyValue<int>, tags$?: LazyValue<int>): void;
    /**
     * Create an exact and synchronized copy of the current screen that can be displayed at another position and Z-order.
     * Both screen share the same internal pixel buffers. Graphical operations are fobidden in the cloned screen
     * @param index The index of the screen to create, will replace an existing screen
     */
    ScreenClone(index?: LazyValue<int>): void;
    /**
     * Make a screen disappear from display. The screen will remain active and drawing operation are still possible after this instruction
     * @param index The index of the screen, if ommited the instruction closes the current screen
     */
    ScreenHide(index?: int): void;
    SetTransparent(index: int | LazyValue<int>): void;
    Screen(index: int | LazyValue<int>): void;
    ScreenToFront(index: int | LazyValue<int>): void;
    ScreenCenter(index: int | LazyValue<int>, centerX: LazyValue<boolean>, centerY: LazyValue<int>): void;
    ScreenWidth(index?: int): int;
    ScreenHeight(index?: int): int;
    ScreenOffset(index: int, xOffset: int, yOffset: int): this;
    ScreenDisplay(index: int, x: int, y: int, width?: int, height?: int): this;
    ScreenScale(index: int, xScale: int, yScale: int): this;
    LoadImage(path: string): void;
    PasteBob(x: int, y: int, index: int): void;
}
export {};
