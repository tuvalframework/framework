import { CGRectangle } from '@tuval/cg';
import { Screen } from '@tuval/core';
import { Brush } from '../drawing/Brush';
import { Pen } from '../drawing/Pen';
import { GuiTVC } from './GuiTVC';
export declare class GuiScreen extends Screen {
    private graphics;
    constructor(tvc: GuiTVC, args: any, tags: any);
    DrawLine(pen: Pen, rect: CGRectangle): void;
    DrawRectangle(pen: Pen, rect: CGRectangle): void;
    FillRectangle(brush: Brush, rect: CGRectangle): void;
    DrawEllipse(pen: Pen, rect: CGRectangle): void;
    FillEllipse(brush: Brush, rect: CGRectangle): void;
}
