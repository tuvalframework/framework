import { TVC } from "@tuval/core";
import { GuiScreen } from "./GUIScreen";
export declare class GuiTVC extends TVC<GuiScreen> {
    CreateScreen(args: any, tags: any): GuiScreen;
}
