import { ConsoleCommandBase, LazyValue, int } from '@tuval/core';
import { GuiConsole } from '../GuiConsole';
import { GuiTVC } from '../GuiTVC';
export declare class ScreenOpenCommand extends ConsoleCommandBase {
    index: LazyValue<int>;
    width: LazyValue<int>;
    height: LazyValue<int>;
    numberOfColor: LazyValue<int>;
    pixelMode: LazyValue<int>;
    columns: LazyValue<int>;
    lines: LazyValue<int>;
    tags$: LazyValue<int>;
    CommandName: string;
    constructor(console: GuiConsole<GuiTVC>, index: LazyValue<int>, width: LazyValue<int>, height: LazyValue<int>, numberOfColor?: LazyValue<int>, pixelMode?: LazyValue<int>, columns?: LazyValue<int>, lines?: LazyValue<int>, tags$?: LazyValue<int>);
    Execute(console: GuiConsole<GuiTVC>): void;
}
