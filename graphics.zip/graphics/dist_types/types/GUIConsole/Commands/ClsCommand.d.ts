import { ConsoleCommandBase, int } from "@tuval/core";
import { LazyValue } from "@tuval/core";
import { GuiConsole } from "../GuiConsole";
import { GuiTVC } from "../GuiTVC";
export declare class ClsCommand extends ConsoleCommandBase {
    ink: LazyValue<int>;
    x: LazyValue<int>;
    y: LazyValue<int>;
    width: LazyValue<int>;
    height: LazyValue<int>;
    CommandName: string;
    constructor(console: GuiConsole<GuiTVC>, ink: LazyValue<int>, x: LazyValue<int>, y: LazyValue<int>, width: LazyValue<int>, height: LazyValue<int>);
    Execute(console: GuiConsole<GuiTVC>): void;
}
