import { ConsoleCommandBase, LazyValue, int } from '@tuval/core';
import { GuiConsole } from '../GuiConsole';
import { GuiTVC } from '../GuiTVC';
export declare class ScreenDisplayCommand extends ConsoleCommandBase {
    index: LazyValue<int>;
    x: LazyValue<int>;
    y: LazyValue<int>;
    width: LazyValue<int>;
    height: LazyValue<int>;
    CommandName: string;
    constructor(console: GuiConsole<GuiTVC>, index: LazyValue<int>, x: LazyValue<int>, y: LazyValue<int>, width: LazyValue<int>, height: LazyValue<int>);
    Execute(console: GuiConsole<GuiTVC>): void;
}
