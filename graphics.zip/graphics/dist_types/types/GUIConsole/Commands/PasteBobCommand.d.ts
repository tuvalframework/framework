import { ConsoleCommandBase, LazyValue } from '@tuval/core';
import { int } from '../../index_web';
import { GuiConsole } from '../GuiConsole';
import { GuiTVC } from '../GuiTVC';
export declare class PasteBobCommand extends ConsoleCommandBase {
    x: LazyValue<int>;
    y: LazyValue<int>;
    imageIndex: LazyValue<int>;
    CommandName: string;
    constructor(console: GuiConsole<GuiTVC>, x: LazyValue<int>, y: LazyValue<int>, imageIndex: LazyValue<int>);
    Execute(console: GuiConsole<GuiTVC>): void;
}
