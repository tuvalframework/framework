import { ConsoleCommandBase, LazyValue, int } from '@tuval/core';
import { GuiConsole } from '../GuiConsole';
import { GuiTVC } from '../GuiTVC';
export declare class ScreenScaleCommand extends ConsoleCommandBase {
    index: LazyValue<int>;
    xScale: LazyValue<int>;
    yScale: LazyValue<int>;
    CommandName: string;
    constructor(console: GuiConsole<GuiTVC>, index: LazyValue<int>, xScale: LazyValue<int>, yScale: LazyValue<int>);
    Execute(console: GuiConsole<GuiTVC>): void;
}
