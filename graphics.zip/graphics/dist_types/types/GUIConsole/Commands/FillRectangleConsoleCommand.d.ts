import { CGRectangle } from "@tuval/cg";
import { ConsoleCommandBase, LazyValue } from "@tuval/core";
import { Brush } from "../../drawing/Brush";
import { GuiConsole } from "../GuiConsole";
import { GuiTVC } from "../GuiTVC";
export declare class FillRectangleConsoleCommand extends ConsoleCommandBase {
    CommandName: string;
    brush: LazyValue<Brush>;
    rect: LazyValue<CGRectangle>;
    constructor(console: GuiConsole<GuiTVC>, brush: LazyValue<Brush>, rect: LazyValue<CGRectangle>);
    Execute(console: GuiConsole<GuiTVC>): void;
}
