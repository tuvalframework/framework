import { ConsoleCommandBase, int } from "@tuval/core";
import { LazyValue } from "@tuval/core";
import { GuiConsole } from "../GuiConsole";
import { GuiTVC } from "../GuiTVC";
export declare class DrawCommand extends ConsoleCommandBase {
    x: LazyValue<int>;
    y: LazyValue<int>;
    width: LazyValue<int>;
    height: LazyValue<int>;
    CommandName: string;
    constructor(console: GuiConsole<GuiTVC>, x: LazyValue<int>, y: LazyValue<int>, width: LazyValue<int>, height: LazyValue<int>);
    Execute(console: GuiConsole<GuiTVC>): void;
}
