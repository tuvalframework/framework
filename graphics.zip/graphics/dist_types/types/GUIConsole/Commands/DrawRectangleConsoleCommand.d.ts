import { CGRectangle } from "@tuval/cg";
import { ConsoleCommandBase } from "@tuval/core";
import { Pen } from "../../drawing/Pen";
import { LazyValue } from "@tuval/core";
import { GuiConsole } from "../GuiConsole";
import { GuiTVC } from "../GuiTVC";
export declare class DrawRectangleConsoleCommand extends ConsoleCommandBase {
    CommandName: string;
    pen: LazyValue<Pen>;
    rect: LazyValue<CGRectangle>;
    constructor(console: GuiConsole<GuiTVC>, pen: LazyValue<Pen>, rect: LazyValue<CGRectangle>);
    Execute(console: GuiConsole<GuiTVC>): void;
}
