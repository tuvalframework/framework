import { ConsoleCommandBase, int } from "@tuval/core";
import { LazyValue } from "@tuval/core";
import { GuiConsole } from "../GuiConsole";
import { GuiTVC } from "../GuiTVC";
export declare class EllipseCommand extends ConsoleCommandBase {
    x: LazyValue<int>;
    y: LazyValue<int>;
    xRadius: LazyValue<int>;
    yRadius: LazyValue<int>;
    CommandName: string;
    constructor(console: GuiConsole<GuiTVC>, x: LazyValue<int>, y: LazyValue<int>, xRadius: LazyValue<int>, yRadius: LazyValue<int>);
    Execute(console: GuiConsole<GuiTVC>): void;
}
