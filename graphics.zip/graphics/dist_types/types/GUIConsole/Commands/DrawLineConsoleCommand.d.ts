import { ConsoleCommandBase, int } from "@tuval/core";
import { Pen } from "../../drawing/Pen";
import { LazyValue } from "@tuval/core";
import { GuiConsole } from "../GuiConsole";
import { GuiTVC } from "../GuiTVC";
export declare class DrawLineConsoleCommand extends ConsoleCommandBase {
    CommandName: string;
    pen: LazyValue<Pen>;
    x1: LazyValue<int>;
    y1: LazyValue<int>;
    x2: LazyValue<int>;
    y2: LazyValue<int>;
    constructor(console: GuiConsole<GuiTVC>, pen: LazyValue<Pen>, x1: LazyValue<int>, y1: LazyValue<int>, x2: LazyValue<int>, y2: LazyValue<int>);
    Execute(console: GuiConsole<GuiTVC>): void;
}
