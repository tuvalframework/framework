import { ConsoleCommandBase, LazyValue, int } from '@tuval/core';
import { GuiConsole } from '../GuiConsole';
import { GuiTVC } from '../GuiTVC';
export declare class ScreenOffsetCommand extends ConsoleCommandBase {
    index: LazyValue<int>;
    x: LazyValue<int>;
    y: LazyValue<int>;
    CommandName: string;
    constructor(console: GuiConsole<GuiTVC>, index: LazyValue<int>, x: LazyValue<int>, y: LazyValue<int>);
    Execute(console: GuiConsole<GuiTVC>): void;
}
