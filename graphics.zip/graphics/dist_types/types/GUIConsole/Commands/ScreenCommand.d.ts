import { ConsoleCommandBase, int } from "@tuval/core";
import { LazyValue } from "@tuval/core";
import { GuiConsole } from "../GuiConsole";
import { GuiTVC } from "../GuiTVC";
export declare class ScreenCommand extends ConsoleCommandBase {
    index: LazyValue<int>;
    CommandName: string;
    constructor(console: GuiConsole<GuiTVC>, index: LazyValue<int>);
    Execute(console: GuiConsole<GuiTVC>): void;
}
