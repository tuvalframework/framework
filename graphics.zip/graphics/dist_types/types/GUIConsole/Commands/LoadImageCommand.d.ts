import { int, SubProcessCommandBase, ImageBank } from '@tuval/core';
import { GuiConsole } from '../GuiConsole';
import { GuiTVC } from '../GuiTVC';
export declare class LoadImageCommand extends SubProcessCommandBase {
    path: string;
    index: int;
    CommandName: string;
    imageBank: ImageBank;
    constructor(console: GuiConsole<GuiTVC>, path: string, index: int);
    Execute(console: GuiConsole<GuiTVC>): void;
    IsWaitable(): boolean;
    GetReturnObject(): any;
}
