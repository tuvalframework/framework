import { ConsoleCommandBase, int } from "@tuval/core";
import { LazyValue } from "@tuval/core";
import { GuiConsole } from "../GuiConsole";
import { GuiTVC } from "../GuiTVC";
export declare class ScreenCenterCommand extends ConsoleCommandBase {
    index: LazyValue<int>;
    centerX: LazyValue<boolean>;
    centerY: LazyValue<boolean>;
    CommandName: string;
    constructor(console: GuiConsole<GuiTVC>, index: LazyValue<int>, centerX: LazyValue<boolean>, centerY: LazyValue<boolean>);
    Execute(console: GuiConsole<GuiTVC>): void;
}
