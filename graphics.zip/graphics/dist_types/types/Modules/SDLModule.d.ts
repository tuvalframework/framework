import { int, uint, CanvasModule, byte, ByteArray } from '@tuval/core';
import { CGColor, CGRectangle, CGSize } from '@tuval/cg';
export declare class SDL_Palette {
    ncolors: int;
    colors: CGColor[];
    version: uint;
    refcount: int;
}
export declare class SDL_PixelFormat {
    format: uint;
    palette: SDL_Palette;
    BitsPerPixel: byte;
    BytesPerPixel: byte;
    padding: ByteArray;
    Rmask: uint;
    Gmask: uint;
    Bmask: uint;
    Amask: uint;
    Rloss: byte;
    Gloss: byte;
    Bloss: byte;
    Aloss: byte;
    Rshift: byte;
    Gshift: byte;
    Bshift: byte;
    Ashift: byte;
    refcount: int;
    next: SDL_PixelFormat;
}
export declare class SDL_Surface {
    Id: int;
    flags: uint; /**< Read-only */
    format: SDL_PixelFormat; /**< Read-only */
    w: int;
    h: int; /**< Read-only */
    pitch: int; /**< Read-only */
    pixels: ByteArray; /**< Read-write */
    /** Application data associated with the surface */
    userdata: ByteArray; /**< Read-write */
    /** information needed for surfaces requiring locks */
    locked: int; /**< Read-only */
    lock_data: ByteArray; /**< Read-only */
    /** clipping information */
    clip_rect: CGRectangle; /**< Read-only */
    /** info for fast blit mapping to other surfaces */
    map: ByteArray; /**< Private */
    /** Reference count -- used when freeing surface */
    refcount: int; /**< Read-mostly */
    constructor();
}
export declare class SDLModule extends CanvasModule {
    private width;
    private height;
    private copyOnLock;
    private discardOnLock;
    private opaqueFrontBuffer;
    private version;
    private surfaces;
    private canvasPool;
    private events;
    private fonts;
    private audios;
    private rwops;
    private music_audio;
    private music_volume;
    private mixerFrequency;
    private mixerFormat;
    private mixerNumChannels;
    private mixerChunkSize;
    private channelMinimumNumber;
    private GL;
    private glAttributes;
    private keyboardState;
    private keyboardMap;
    private canRequestFullscreen;
    private isRequestingFullscreen;
    private textInput;
    private startTime;
    private initFlags;
    private buttonState;
    private modState;
    private DOMButtons;
    private DOMEventToSDLEvent;
    private TOUCH_DEFAULT_ID;
    private eventHandler;
    private eventHandlerContext;
    private eventHandlerTemp;
    private keyCodes;
    private scanCodes;
    private screen;
    private channels;
    private numChannels;
    private audioContext;
    constructor(width: int, height: int);
    private loadRect;
    private updateRect;
    private intersectionOfRects;
    private checkPixelFormat;
    private loadColorToCSSRGB;
    private loadColorToCSSRGBA;
    private translateColorToCSSRGBA;
    private translateRGBAToCSSRGBA;
    private translateRGBAToColor;
    private makeSurface;
    private copyIndexedColorData;
    private freeSurface;
    protected BlitSurface(src: SDL_Surface, srcrect: CGRectangle, dst: SDL_Surface, dstrect: CGRectangle, scale: any): number;
    private downFingers;
    private savedKeydown;
    private receiveEvent;
    private lookupKeyCodeForEvent;
    private handleEvent;
    private flushEventsToHandler;
    private pollEvent;
    private makeCEvent;
    private makeFontString;
    private estimateTextWidth;
    private allocateChannels;
    private setGetVolume;
    private setPannerPosition;
    private playWebAudio;
    private pauseWebAudio;
    private openAudioContext;
    private webAudioAvailable;
    private fillWebAudioBufferFromHeap;
    private debugSurface;
    private joystickEventState;
    private lastJoystickState;
    private joystickNamePool;
    private recordJoystickState;
    private getJoystickButtonState;
    private queryJoysticks;
    private joystickAxisValueConversion;
    private getGamepads;
    private getGamepad;
    private _SDL_FillRect;
    private _SDL_Flip;
    private doNotCaptureKeyboard;
    private keyboardListeningElement;
    /** @param{number=} initFlags */
    private _SDL_Init;
    private _SDL_MapRGBA;
    private _SDL_AudioQuit;
    private _SDL_Quit;
    private addedResizeListener;
    private settingVideoMode;
    private _SDL_SetVideoMode;
    private _SDL_UnlockSurface;
    private _SDL_UpperBlit;
    private ttfContext;
    private _TTF_Init;
    private _TTF_OpenFont;
    private _TTF_RenderText_Solid;
    private _abort;
    private _SDL_GetTicks;
    private screenIsReadOnly;
    private _SDL_LockSurface;
    private unicode;
    /** @suppress{missingProperties} */
    private SDL_unicode;
    /** @suppress{missingProperties} */
    private SDL_ttfContext;
    private audio;
    /** @suppress{missingProperties} */
    private SDL_audio;
    protected requestFullscreen(lockPointer: any, resizeCanvas: any): void;
    protected requestFullScreen(): void;
    protected requestAnimationFrame(func: any): void;
    protected setCanvasSize(width: any, height: any, noUpdates: any): void;
    protected pauseMainLoop(): void;
    protected resumeMainLoop(): void;
    protected getUserMedia(): void;
    protected createContext(canvas: any, useWebGL: any, setInModule: any, webGLContextAttributes: any): CanvasRenderingContext2D;
    protected _emscripten_get_canvas_element_size(): CGSize;
}
