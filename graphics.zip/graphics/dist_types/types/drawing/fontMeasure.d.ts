import { float } from "@tuval/core";
export interface IFontMetrics {
    top: float;
    bottom: float;
    lineHeight: float;
    alphabetic: float;
    baseline: float;
    middle: float;
    median: float;
    hanging: float;
    ideographic: float;
    upper: float;
    capHeight: float;
    lower: float;
    xHeight: float;
    tittle: float;
    ascent: float;
    descent: float;
    overshoot: float;
}
export declare function measureFont(font: any, o: any): IFontMetrics;
export declare namespace measureFont {
    var canvas: HTMLCanvasElement;
    var cache: {};
}
