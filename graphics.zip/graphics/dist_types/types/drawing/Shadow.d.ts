import { CGColor } from '@tuval/cg';
/**
 * This class encapsulates the properties required to define a shadow to apply to a {@link DisplayObject}
 * via its `shadow` property.
 *
 * @memberof easeljs
 * @example
 * img.shadow = new Shadow("#000000", 5, 5, 10);
 *
 * @param {String} [color=black] The color of the shadow. This can be any valid CSS color value.
 * @param {Number} [offsetX=0] The x offset of the shadow in pixels.
 * @param {Number} [offsetY=0] The y offset of the shadow in pixels.
 * @param {Number} [blur=0] The size of the blurring effect.
 */
export declare class Shadow {
    /**
     * The color of the shadow. This can be any valid CSS color value.
     * @type {String}
     * @default black
     */
    color: CGColor;
    /**
     * The x offset of the shadow.
     * @type {Number}
     * @default 0
     */
    offsetX: number;
    /**
     * The y offset of the shadow.
     * @type {Number}
     * @default 0
     */
    offsetY: number;
    /**
     * The blur of the shadow.
     * @type {Number}
     * @default 0
     */
    blur: number;
    static identity: Shadow;
    constructor(color?: CGColor, offsetX?: number, offsetY?: number, blur?: number);
    /**
     * Returns a string representation of this object.
     * @return {String}
     */
    toString(): string;
    /**
     * Returns a clone of this Shadow instance.
     * @return {Shadow} A clone of the current Shadow instance.
     */
    clone(): Shadow;
}
