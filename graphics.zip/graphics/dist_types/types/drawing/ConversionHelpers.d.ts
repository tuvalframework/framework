import { CGRectangle } from '@tuval/cg';
import { GraphicsUnit } from './GraphicsUnit';
import { float, Out } from '@tuval/core';
import { Graphics } from './Graphics';
import { CoordinateSpace } from './drawing2D/CoordinateSpace';
import { Matrix } from './drawing2D/Matrix';
export declare class ConversionHelpers {
    static GraphicsUnitConversion(from: GraphicsUnit, to: GraphicsUnit, dpiX: float, dpiY: float, srcRect: Out<CGRectangle>): void;
    static GraphicsUnitConversion1(from: GraphicsUnit, to: GraphicsUnit, dpi: float, nSrc: float): float;
    static GetGraphicsTransform(graphics: Graphics, destinationSpace: CoordinateSpace, sourceSpace: CoordinateSpace, matrix: Out<Matrix>): void;
}
