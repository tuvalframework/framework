import { SketchGraphics } from "./SketchGraphics";
interface ISketchCommand {
    exec(sg: SketchGraphics, data?: any): void;
}
export declare class SketchBatch {
    protected m_instructions: ISketchCommand[];
    command: ISketchCommand;
    protected m_dirty: boolean;
    append(command: ISketchCommand, clean?: boolean): void;
    fill(color: string): void;
    rect(x: number, y: number, w: number, h: number): void;
    translate(x: number, y: number): void;
    draw(sg: SketchGraphics, data?: any): void;
    clear(): void;
}
export {};
