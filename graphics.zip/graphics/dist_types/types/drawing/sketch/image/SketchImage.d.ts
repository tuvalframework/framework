import { int } from '@tuval/core';
import { CGColor } from '@tuval/cg';
export declare class SketchImage {
    width: number;
    height: number;
    canvas: HTMLCanvasElement;
    drawingContext: CanvasRenderingContext2D;
    _pixelDensity: number;
    _modified: boolean;
    _pixelsDirty: boolean;
    pixels: any;
    imageData: any;
    constructor(width: number, height: number, inst?: any);
    _setProperty(prop: any, value: any): void;
    loadPixels(): void;
    updatePixels(x: any, y: any, w: any, h: any): void;
    get(x: any, y: any, w: any, h: any): any[] | SketchImage;
    private _getPixel;
    set(x: int, y: int, imgOrCol: CGColor): void;
    resize(width: any, height: any): void;
    copy(): void;
    private static _copyHelper;
    mask(p5Image: any): void;
    filter(operation: any, value: any): void;
    blend(): void;
    setModified: (val: any) => void;
    isModified(): boolean;
    save(filename: any, extension: any): void;
}
