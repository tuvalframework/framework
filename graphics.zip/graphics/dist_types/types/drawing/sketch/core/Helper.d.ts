export declare function modeAdjust(a: any, b: any, c: any, d: any, mode: any): {
    x: any;
    y: any;
    w: any;
    h: any;
} | undefined;
export declare function arcModeAdjust(a: any, b: any, c: any, d: any, mode: any): {
    x: any;
    y: any;
    w: any;
    h: any;
} | undefined;
