/**
 * @module Constants
 * @submodule Constants
 * @for p5
 */
export declare const constants: {
    /**
     * @property {String} P2D
     * @final
     */
    P2D: string;
    /**
     * @property {String} WEBGL
     * @final
     */
    WEBGL: string;
    /**
     * @property {String} ARROW
     * @final
     */
    ARROW: string;
    /**
     * @property {String} CROSS
     * @final
     */
    CROSS: string;
    /**
     * @property {String} HAND
     * @final
     */
    HAND: string;
    /**
     * @property {String} MOVE
     * @final
     */
    MOVE: string;
    /**
     * @property {String} TEXT
     * @final
     */
    TEXT: string;
    /**
     * @property {String} WAIT
     * @final
     */
    WAIT: string;
    /**
     * HALF_PI is a mathematical constant with the value
     * 1.57079632679489661923. It is half the ratio of the
     * circumference of a circle to its diameter. It is useful in
     * combination with the trigonometric functions <a href="#/p5/sin">sin()</a> and <a href="#/p5/cos">cos()</a>.
     *
     * @property {Number} HALF_PI
     * @final
     *
     * @example
     * <div><code>
     * arc(50, 50, 80, 80, 0, HALF_PI);
     * </code></div>
     *
     * @alt
     * 80x80 white quarter-circle with curve toward bottom right of canvas.
     *
     */
    HALF_PI: number;
    /**
     * PI is a mathematical constant with the value
     * 3.14159265358979323846. It is the ratio of the circumference
     * of a circle to its diameter. It is useful in combination with
     * the trigonometric functions <a href="#/p5/sin">sin()</a> and <a href="#/p5/cos">cos()</a>.
     *
     * @property {Number} PI
     * @final
     *
     * @example
     * <div><code>
     * arc(50, 50, 80, 80, 0, PI);
     * </code></div>
     *
     * @alt
     * white half-circle with curve toward bottom of canvas.
     *
     */
    PI: number;
    /**
     * QUARTER_PI is a mathematical constant with the value 0.7853982.
     * It is one quarter the ratio of the circumference of a circle to
     * its diameter. It is useful in combination with the trigonometric
     * functions <a href="#/p5/sin">sin()</a> and <a href="#/p5/cos">cos()</a>.
     *
     * @property {Number} QUARTER_PI
     * @final
     *
     * @example
     * <div><code>
     * arc(50, 50, 80, 80, 0, QUARTER_PI);
     * </code></div>
     *
     * @alt
     * white eighth-circle rotated about 40 degrees with curve bottom right canvas.
     *
     */
    QUARTER_PI: number;
    /**
     * TAU is an alias for TWO_PI, a mathematical constant with the
     * value 6.28318530717958647693. It is twice the ratio of the
     * circumference of a circle to its diameter. It is useful in
     * combination with the trigonometric functions <a href="#/p5/sin">sin()</a> and <a href="#/p5/cos">cos()</a>.
     *
     * @property {Number} TAU
     * @final
     *
     * @example
     * <div><code>
     * arc(50, 50, 80, 80, 0, TAU);
     * </code></div>
     *
     * @alt
     * 80x80 white ellipse shape in center of canvas.
     *
     */
    TAU: number;
    /**
     * TWO_PI is a mathematical constant with the value
     * 6.28318530717958647693. It is twice the ratio of the
     * circumference of a circle to its diameter. It is useful in
     * combination with the trigonometric functions <a href="#/p5/sin">sin()</a> and <a href="#/p5/cos">cos()</a>.
     *
     * @property {Number} TWO_PI
     * @final
     *
     * @example
     * <div><code>
     * arc(50, 50, 80, 80, 0, TWO_PI);
     * </code></div>
     *
     * @alt
     * 80x80 white ellipse shape in center of canvas.
     *
     */
    TWO_PI: number;
    /**
     * Constant to be used with <a href="#/p5/angleMode">angleMode()</a> function, to set the mode which
     * p5.js interprates and calculates angles (either DEGREES or RADIANS).
     * @property {String} DEGREES
     * @final
     *
     * @example
     * <div class='norender'><code>
     * function setup() {
     *   angleMode(DEGREES);
     * }
     * </code></div>
     */
    DEGREES: string;
    /**
     * Constant to be used with <a href="#/p5/angleMode">angleMode()</a> function, to set the mode which
     * p5.js interprates and calculates angles (either RADIANS or DEGREES).
     * @property {String} RADIANS
     * @final
     *
     * @example
     * <div class='norender'><code>
     * function setup() {
     *   angleMode(RADIANS);
     * }
     * </code></div>
     */
    RADIANS: string;
    DEG_TO_RAD: number;
    RAD_TO_DEG: number;
    /**
     * @property {String} CORNER
     * @final
     */
    CORNER: string;
    /**
     * @property {String} CORNERS
     * @final
     */
    CORNERS: string;
    /**
     * @property {String} RADIUS
     * @final
     */
    RADIUS: string;
    /**
     * @property {String} RIGHT
     * @final
     */
    RIGHT: string;
    /**
     * @property {String} LEFT
     * @final
     */
    LEFT: string;
    /**
     * @property {String} CENTER
     * @final
     */
    CENTER: string;
    /**
     * @property {String} TOP
     * @final
     */
    TOP: string;
    /**
     * @property {String} BOTTOM
     * @final
     */
    BOTTOM: string;
    /**
     * @property {String} BASELINE
     * @final
     * @default alphabetic
     */
    BASELINE: string;
    /**
     * @property {Number} POINTS
     * @final
     * @default 0x0000
     */
    POINTS: number;
    /**
     * @property {Number} LINES
     * @final
     * @default 0x0001
     */
    LINES: number;
    /**
     * @property {Number} LINE_STRIP
     * @final
     * @default 0x0003
     */
    LINE_STRIP: number;
    /**
     * @property {Number} LINE_LOOP
     * @final
     * @default 0x0002
     */
    LINE_LOOP: number;
    /**
     * @property {Number} TRIANGLES
     * @final
     * @default 0x0004
     */
    TRIANGLES: number;
    /**
     * @property {Number} TRIANGLE_FAN
     * @final
     * @default 0x0006
     */
    TRIANGLE_FAN: number;
    /**
     * @property {Number} TRIANGLE_STRIP
     * @final
     * @default 0x0005
     */
    TRIANGLE_STRIP: number;
    /**
     * @property {String} QUADS
     * @final
     */
    QUADS: string;
    /**
     * @property {String} QUAD_STRIP
     * @final
     * @default quad_strip
     */
    QUAD_STRIP: string;
    /**
     * @property {String} CLOSE
     * @final
     */
    CLOSE: string;
    /**
     * @property {String} OPEN
     * @final
     */
    OPEN: string;
    /**
     * @property {String} CHORD
     * @final
     */
    CHORD: string;
    /**
     * @property {String} PIE
     * @final
     */
    PIE: string;
    /**
     * @property {String} PROJECT
     * @final
     * @default square
     */
    PROJECT: string;
    /**
     * @property {String} SQUARE
     * @final
     * @default butt
     */
    SQUARE: string;
    /**
     * @property {String} ROUND
     * @final
     */
    ROUND: string;
    /**
     * @property {String} BEVEL
     * @final
     */
    BEVEL: string;
    /**
     * @property {String} MITER
     * @final
     */
    MITER: string;
    /**
     * @property {String} RGB
     * @final
     */
    RGB: string;
    /**
     * @property {String} HSB
     * @final
     */
    HSB: string;
    /**
     * @property {String} HSL
     * @final
     */
    HSL: string;
    /**
     * @property {String} AUTO
     * @final
     */
    AUTO: string;
    ALT: number;
    BACKSPACE: number;
    CONTROL: number;
    DELETE: number;
    DOWN_ARROW: number;
    ENTER: number;
    ESCAPE: number;
    LEFT_ARROW: number;
    OPTION: number;
    RETURN: number;
    RIGHT_ARROW: number;
    SHIFT: number;
    TAB: number;
    UP_ARROW: number;
    /**
     * @property {String} BLEND
     * @final
     * @default source-over
     */
    BLEND: string;
    /**
     * @property {String} ADD
     * @final
     * @default lighter
     */
    ADD: string;
    /**
     * @property {String} DARKEST
     * @final
     */
    DARKEST: string;
    /**
     * @property {String} LIGHTEST
     * @final
     * @default lighten
     */
    LIGHTEST: string;
    /**
     * @property {String} DIFFERENCE
     * @final
     */
    DIFFERENCE: string;
    SUBTRACT: string;
    /**
     * @property {String} EXCLUSION
     * @final
     */
    EXCLUSION: string;
    /**
     * @property {String} MULTIPLY
     * @final
     */
    MULTIPLY: string;
    /**
     * @property {String} SCREEN
     * @final
     */
    SCREEN: string;
    /**
     * @property {String} REPLACE
     * @final
     * @default copy
     */
    REPLACE: string;
    /**
     * @property {String} OVERLAY
     * @final
     */
    OVERLAY: string;
    /**
     * @property {String} HARD_LIGHT
     * @final
     */
    HARD_LIGHT: string;
    /**
     * @property {String} SOFT_LIGHT
     * @final
     */
    SOFT_LIGHT: string;
    /**
     * @property {String} DODGE
     * @final
     * @default color-dodge
     */
    DODGE: string;
    /**
     * @property {String} BURN
     * @final
     * @default color-burn
     */
    BURN: string;
    /**
     * @property {String} THRESHOLD
     * @final
     */
    THRESHOLD: string;
    /**
     * @property {String} GRAY
     * @final
     */
    GRAY: string;
    /**
     * @property {String} OPAQUE
     * @final
     */
    OPAQUE: string;
    /**
     * @property {String} INVERT
     * @final
     */
    INVERT: string;
    /**
     * @property {String} POSTERIZE
     * @final
     */
    POSTERIZE: string;
    /**
     * @property {String} DILATE
     * @final
     */
    DILATE: string;
    /**
     * @property {String} ERODE
     * @final
     */
    ERODE: string;
    /**
     * @property {String} BLUR
     * @final
     */
    BLUR: string;
    /**
     * @property {String} NORMAL
     * @final
     */
    NORMAL: string;
    /**
     * @property {String} ITALIC
     * @final
     */
    ITALIC: string;
    /**
     * @property {String} BOLD
     * @final
     */
    BOLD: string;
    _DEFAULT_TEXT_FILL: string;
    _DEFAULT_LEADMULT: number;
    _CTX_MIDDLE: string;
    LINEAR: string;
    QUADRATIC: string;
    BEZIER: string;
    CURVE: string;
    STROKE: string;
    FILL: string;
    TEXTURE: string;
    IMMEDIATE: string;
    NEAREST: string;
    REPEAT: string;
    CLAMP: string;
    MIRROR: string;
    /**
     * @property {String} LANDSCAPE
     * @final
     */
    LANDSCAPE: string;
    /**
     * @property {String} PORTRAIT
     * @final
     */
    PORTRAIT: string;
    POLYGON: string;
    BOLDITALIC: string;
    _DEFAULT_STROKE: string;
    _DEFAULT_FILL: string;
};
type ADD = "lighter";
type ARROW = "arrow";
type AUDIO = "audio";
type AUTO = "auto";
type AXES = "axes";
type BASELINE = "alphabetic";
type BEVEL = "bevel";
type BLEND = "source-over";
type BLUR = "blur";
type BOLD = "bold";
type BOTTOM = "bottom";
type BURN = "color-burn";
type CENTER = "center";
type CHORD = "chord";
type CLOSE = "close";
type CORNER = "corner";
type CORNERS = "corners";
type CROSS = "cross";
type DARKEST = "darkest";
type DEGREES = "degrees";
type DIFFERENCE = "difference";
type DILATE = "dilate";
type DODGE = "color-dodge";
type ERODE = "erode";
type EXCLUSION = "exclusion";
type GRAY = "gray";
type GRID = "grid";
type HAND = "hand";
type HARD_LIGHT = "hard-light";
type HSB = "hsb";
type HSL = "hsl";
type INVERT = "invert";
type ITALIC = "italic";
type LEFT = "left";
type LIGHTEST = "lighten";
type LINES = 0x0001;
type MITER = "miter";
type MOVE = "move";
type MULTIPLY = "multiply";
type NORMAL = "normal";
type OPAQUE = "opaque";
type OPEN = "open";
type OVERLAY = "overlay";
type P2D = "p2d";
type PIE = "pie";
type POINTS = 0x0000;
type POSTERIZE = "posterize";
type PROJECT = "square";
type QUAD_STRIP = "quad_strip";
type QUADS = "quads";
type RADIANS = "radians";
type RADIUS = "radius";
type REPLACE = "copy";
type RGB = "rgb";
type RIGHT = "right";
type ROUND = "round";
type SCREEN = "screen";
type SOFT_LIGHT = "soft-light";
type SQUARE = "butt";
type TEXT = "text";
type THRESHOLD = "threshold";
type TOP = "top";
type TRIANGLE_FAN = 0x0006;
type TRIANGLE_STRIP = 0x0005;
type TRIANGLES = 0x0004;
type VIDEO = "video";
type WAIT = "wait";
type WEBGL = "webgl";
export type ANGLE_MODE = RADIANS | DEGREES;
export type ARC_MODE = CHORD | PIE | OPEN;
export type BEGIN_KIND = POINTS | LINES | TRIANGLES | TRIANGLE_FAN | TRIANGLE_STRIP | QUADS | QUAD_STRIP;
export type BLEND_MODE = BLEND | DARKEST | LIGHTEST | DIFFERENCE | MULTIPLY | EXCLUSION | SCREEN | REPLACE | OVERLAY | HARD_LIGHT | SOFT_LIGHT | DODGE | BURN | ADD | NORMAL;
export type COLOR_MODE = RGB | HSB | HSL;
export type CURSOR_TYPE = ARROW | CROSS | HAND | MOVE | TEXT | WAIT;
export type DEBUG_MODE = GRID | AXES;
export type ELLIPSE_MODE = CENTER | RADIUS | CORNER | CORNERS;
export type END_MODE = CLOSE;
export type FILTER_TYPE = THRESHOLD | GRAY | OPAQUE | INVERT | POSTERIZE | BLUR | ERODE | DILATE;
export type GRAPHICS_RENDERER = P2D | WEBGL;
export type HORIZ_ALIGN = LEFT | CENTER | RIGHT;
export type IMAGE_MODE = CORNER | CORNERS | CENTER;
export type RECT_MODE = CORNER | CORNERS | CENTER | RADIUS;
export type RENDERER = P2D | WEBGL;
export type SIZE_H = AUTO;
export type SIZE_W = AUTO;
export type STROKE_CAP = SQUARE | PROJECT | ROUND;
export type STROKE_JOIN = MITER | BEVEL | ROUND;
export type THE_STYLE = NORMAL | ITALIC | BOLD;
export type TYPE = VIDEO | AUDIO;
export type VERT_ALIGN = TOP | BOTTOM | CENTER | BASELINE;
export {};
