import { SketchGraphics } from "../SketchGraphics";
export declare class SketchFont {
    parent: SketchGraphics;
    cache: {};
    font: any;
    constructor(p: SketchGraphics);
    list(): void;
    textBounds(str: any, x: any, y: any, fontSize: any, options: any): any;
    textToPoints(txt: any, x: any, y: any, fontSize: any, options: any): any[];
    _getGlyphs(str: any): any;
    _getPath(line: any, x: any, y: any, options: any): any;
    _getPathData(line: any, x: any, y: any, options: any): any;
    _getSVG(line: any, x: any, y: any, options: any): any;
    _renderPath(line: any, x: any, y: any, options: any): this;
    _textWidth(str: any, fontSize: any): any;
    _textAscent(fontSize: any): number;
    _textDescent(fontSize: any): number;
    _scale(fontSize: any): number;
    _handleAlignment(renderer: any, line: any, x: any, y: any, textWidth?: any): {
        x: any;
        y: any;
    };
}
