import { IDisposable } from "@tuval/core";
import { ICloneable } from "./ICloneable";
import { Graphics } from "./Graphics";
import { Shadow } from "./Shadow";
export declare class Brush implements IDisposable, ICloneable<Brush> {
    protected changed: boolean;
    Shadow: Shadow;
    Dispose(): void;
    Clone(): Brush;
    setup(graphics: Graphics, fill: boolean): void;
}
