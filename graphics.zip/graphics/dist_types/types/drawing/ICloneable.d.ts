export interface ICloneable<T> {
    Clone(): T;
}
