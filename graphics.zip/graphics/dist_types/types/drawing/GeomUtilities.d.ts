import { CGRectangle, CGPoint, CGSize, CGAffineTransform } from '@tuval/cg';
import { float, Out } from '@tuval/core';
import { Blend } from './drawing2D/Blend';
import { Matrix } from './drawing2D/Matrix';
import { CurveType } from './drawing2D/GraphicsPath';
export declare class GeomUtilities {
    static ComputeOrientationLine(rect: CGRectangle, angle: float, start: Out<CGPoint>, end: Out<CGPoint>): void;
    static ToRadians(degrees: float): float;
    static Lerp(value1: float, value2: float, amount: float): float;
    static SigmaBellShape(focus: float, scale: float): Blend;
    static Phi(x: float): float;
    static Erf(x: float): float;
    static CreateGeometricTransform(rect: CGRectangle, points: CGPoint[]): CGAffineTransform;
    static CreateRotateFlipTransform(width: Out<number>, height: Out<number>, angle: float, flipX: boolean, flipY: boolean): CGAffineTransform;
    static TransformRectangle(rectangle: Out<CGRectangle>, matrix: Matrix): void;
    static GetCurveTangents(terms: number, points: CGPoint[], count: number, tension: float, type: CurveType): CGPoint[];
    private static quadCubeCoeff;
    static QuadraticToCubic(start: CGPoint, controlPoint: CGPoint, end: CGPoint, controlPoint1: Out<CGPoint>, controlPoint2: Out<CGPoint>): void;
    static DotProduct(u: CGPoint, v: CGPoint): float;
    static Normal(v: CGPoint): float;
    static CrossProduct(v1: CGPoint, v2: CGPoint): float;
    static TriangleBoundingBox(points: CGPoint[]): CGRectangle;
    static PolygonBoundingBox(points: CGPoint[]): CGRectangle;
    static PolygonCentroid(points: CGPoint[]): CGPoint;
    static PolygonArea(points: CGPoint[]): float;
    static InflateRect(a: Out<CGRectangle>, w: float, h: float): void;
    static IntersectionRect(a: CGRectangle, b: CGRectangle): CGRectangle;
    static ContainsRect(a: CGRectangle, b: CGPoint): boolean;
    static ContainsRect(a: CGRectangle, b: CGRectangle): boolean;
    static IntersectsLineSegment(rect: CGRectangle, p1: CGPoint, p2: CGPoint): boolean;
    static IntersectsRect(a: CGRectangle, b: CGRectangle): boolean;
    static ComparePointWithLine(a1: CGPoint, a2: CGPoint, p: CGPoint): number;
    static IntersectingLines(a1: CGPoint, a2: CGPoint, b1: CGPoint, b2: CGPoint): boolean;
    static LineBounds(a: CGPoint, b: CGPoint): CGRectangle;
    static LineContainsPoint(a: CGPoint, b: CGPoint, fuzz: float, p: CGPoint): boolean;
    static NearestIntersectionOnLine(a: CGPoint, b: CGPoint, p: CGPoint, q: CGPoint, result: Out<CGPoint>): boolean;
    static RectFromLine(a: CGPoint, b: CGPoint, w: float): CGRectangle;
    static NearestPointOnLine(a: CGPoint, b: CGPoint, p: CGPoint, result: Out<CGPoint>): boolean;
    static GetNearestIntersectionPoint(rect: CGRectangle, p1: CGPoint, p2: CGPoint, result: Out<CGPoint>): boolean;
    static LargestSizeKeepingAspectRatio(target: CGSize, aspect: CGSize): CGSize;
    static MakeRect(x: float): CGRectangle;
    static MakeRect(p: CGPoint): CGRectangle;
    static MakeRect(s: CGSize): CGRectangle;
    static UnionRect(a: CGRectangle, b: CGRectangle): CGRectangle;
    static UnionRect(r: CGRectangle, p: CGPoint): CGRectangle;
    private static lineBounds;
    static BezierBounds(s: CGPoint, c1: CGPoint, c2: CGPoint, e: CGPoint, epsilon: number): CGRectangle;
    static BezierContainsPoint(s: CGPoint, c1: CGPoint, c2: CGPoint, e: CGPoint, epsilon: number, p: CGPoint): boolean;
    static BezierMidPoint(b0: CGPoint, b1: CGPoint, b2: CGPoint, b3: CGPoint, v: Out<CGPoint>, w: Out<CGPoint>): void;
    static BezierNearestIntersectionOnLine(s: CGPoint, c1: CGPoint, c2: CGPoint, e: CGPoint, p1: CGPoint, p2: CGPoint, epsilon: number, /*out*/ result: Out<CGPoint>): boolean;
    static RescalePoints(v: CGPoint[], oldr: CGRectangle, newr: CGRectangle): void;
    static ExpandPointOnEdge(p: CGPoint, rect: CGRectangle, shift: float): CGPoint;
    static TranslatePoints(v: CGPoint[], dx: number, dy: number): void;
    static GetAngle(x: number, y: number): number;
    static NearestIntersectionOnArc(rect: CGRectangle, p1: CGPoint, p2: CGPoint, result: Out<CGPoint>, startAngle: float, sweepAngle: float): boolean;
    static NearestIntersectionOnEllipse(rect: CGRectangle, p1: CGPoint, p2: CGPoint, result: Out<CGPoint>): boolean;
    /**
     * Get surrounding rectangle of  given rect with angle.
     * @param angleInDeg
     * @param rect
     */
    static GetSurroundingRectangle(angleInDeg: float, rect: CGRectangle): CGPoint[];
    static CheckLineIntersection(line1StartX: number, line1StartY: number, line1EndX: number, line1EndY: number, line2StartX: number, line2StartY: number, line2EndX: number, line2EndY: number): any;
}
