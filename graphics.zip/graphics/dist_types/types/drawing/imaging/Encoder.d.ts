import { Guid } from '@tuval/core';
export declare class Encoder {
    private guid;
    static readonly ChrominanceTable: Encoder;
    static readonly ColorDepth: Encoder;
    static readonly Compression: Encoder;
    static readonly LuminanceTable: Encoder;
    static readonly Quality: Encoder;
    static readonly RenderMethod: Encoder;
    static readonly SaveFlag: Encoder;
    static readonly ScanMethod: Encoder;
    static readonly Transformation: Encoder;
    static readonly Version: Encoder;
    static StaticConstructor(): void;
    constructor(guid: string);
    constructor(guid: Guid);
    get Guid(): Guid;
}
