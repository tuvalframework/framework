import { IDisposable, int, IntPtr } from '@tuval/core';
import { EncoderParameter } from './EncoderParameter';
export declare class EncoderParameters implements IDisposable {
    private parameters;
    constructor();
    constructor(count: int);
    get Param(): EncoderParameter[];
    set Param(value: EncoderParameter[]);
    Dispose(): void;
    ToNativePtr(): IntPtr;
    static FromNativePtr(epPtr: IntPtr): EncoderParameters;
}
