import { IDisposable, int, IntPtr } from '@tuval/core';
import { Encoder } from './Encoder';
import { EncoderParameterValueType } from './EncoderParameterValueType';
export declare class EncoderParameter implements IDisposable {
    private encoder;
    private valuesCount;
    private type;
    private valuePtr;
    constructor();
    get Encoder(): Encoder;
    set Encoder(value: Encoder);
    get NumberOfValues(): int;
    get Type(): EncoderParameterValueType;
    get ValueType(): EncoderParameterValueType;
    dispose(disposing: boolean): void;
    Dispose(): void;
    static NativeSize(): int;
    ToNativePtr(epPtr: IntPtr): void;
    static FromNativePtr(epPtr: IntPtr): EncoderParameter;
}
