import { int, short, ByteArray } from '@tuval/core';
export declare class PropertyItem {
    private id;
    private len;
    private type;
    private value;
    constructor();
    get Id(): int;
    set Id(value: int);
    get Len(): int;
    set Len(value: int);
    get Type(): short;
    set Type(value: short);
    get Value(): ByteArray;
    set Value(value: ByteArray);
}
