import { Guid, int } from '@tuval/core';
export declare class FrameDimension {
    private guid;
    private name;
    private static page;
    private static resolution;
    private static time;
    constructor(guid: Guid);
    constructor(guid: Guid, name: string);
    get Guid(): Guid;
    static get Page(): FrameDimension;
    static get Resolution(): FrameDimension;
    static get Time(): FrameDimension;
    Equals(o: FrameDimension): boolean;
    GetHashCode(): int;
    ToString(): string;
}
