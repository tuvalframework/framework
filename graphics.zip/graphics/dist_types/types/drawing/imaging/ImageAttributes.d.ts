import { CGColor } from '@tuval/cg';
import { ColorMatrix } from "../ColorMatrix";
import { ColorMatrixFlag } from "./ColorMatrixFlag";
import { ColorAdjustType } from "./ColorAdjustType";
import { ICloneable, IDisposable, float } from "@tuval/core";
import { WrapMode } from "../drawing2D/WrapMode";
export declare class ImageAttributes implements ICloneable<ImageAttributes>, IDisposable {
    colorMatrix: ColorMatrix;
    colorMatrixFlags: ColorMatrixFlag;
    colorAdjustType: ColorAdjustType;
    gamma: float;
    isColorMatrixSet: boolean;
    isGammaSet: boolean;
    clearColorMatrix(): void;
    clearGamma(type?: ColorAdjustType): void;
    setColorMatrix(newColorMatrix: ColorMatrix): void;
    setColorMatrix(newColorMatrix: ColorMatrix, flags: ColorMatrixFlag): void;
    setColorMatrix(newColorMatrix: ColorMatrix, mode: ColorMatrixFlag, type: ColorAdjustType): void;
    setGamma(gamma: float): void;
    setGamma(gamma: float, type: ColorAdjustType): void;
    setWrapMode(mode: WrapMode): void;
    setWrapMode(mode: WrapMode, color: CGColor): void;
    setWrapMode(mode: WrapMode, color: CGColor, clamp: boolean): void;
    SetColorKey(lowColor: CGColor, highColor: CGColor): void;
    SetColorKey(lowColor: CGColor, highColor: CGColor, type: ColorAdjustType): void;
    Clone(): ImageAttributes;
    Dispose(): void;
}
