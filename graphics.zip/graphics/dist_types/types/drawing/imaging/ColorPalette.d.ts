import { CGColor } from '@tuval/cg';
import { int, IntPtr } from '@tuval/core';
export declare class ColorPalette {
    private flags;
    private entries;
    constructor();
    constructor(flags: int, colors: CGColor[]);
    get Entries(): CGColor[];
    get Flags(): int;
    getGDIPalette(): IntPtr;
    setFromGDIPalette(palette: IntPtr): void;
}
