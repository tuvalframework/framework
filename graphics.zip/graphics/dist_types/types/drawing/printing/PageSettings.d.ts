export declare class PageSettings {
    PrinterSettings: any;
}
