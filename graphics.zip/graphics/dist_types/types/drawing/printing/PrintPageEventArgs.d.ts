import { CGRectangle } from '@tuval/cg';
import { Graphics } from "../Graphics";
import { PageSettings } from "./PageSettings";
import { EventArgs } from "@tuval/core";
export declare class PrintPageEventArgs extends EventArgs {
    MarginBounds: CGRectangle;
    Graphics: Graphics;
    PageSettings: PageSettings;
    HasMorePages: boolean;
}
