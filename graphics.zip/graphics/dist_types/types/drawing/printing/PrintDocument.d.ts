import { PageSettings } from "./PageSettings";
export declare class PrintDocument {
    DocumentName: string;
    DefaultPageSettings: PageSettings;
    print(): void;
}
