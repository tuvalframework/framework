import { CGImage } from '@tuval/cg';
import { List } from "@tuval/core";
export declare class ImageList extends List<CGImage> {
}
