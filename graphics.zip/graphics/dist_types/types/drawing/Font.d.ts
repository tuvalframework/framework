import { IContext2D } from '@tuval/cg';
import { float } from '@tuval/core';
import { CGFont } from '@tuval/cg';
import { FontFamily } from './FontFamily';
import { int } from '@tuval/core';
export declare class Font extends CGFont {
    private static _ctx;
    get Height(): int;
    constructor(fontFamily: /* opentype.Font | */ FontFamily | string, size: float);
    setup(graphics: IContext2D): void;
    protected _prepContext(ctx: any): any;
    getHeight(): number;
    getTextWidth(text: string): number;
    equals(font: Font): boolean;
    GetCellAscent(): float;
    GetHeight(): float;
}
