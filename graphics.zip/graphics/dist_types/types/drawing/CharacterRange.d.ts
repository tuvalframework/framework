export declare class CharacterRange {
    private _first;
    private _length;
    constructor(first: number, length: number);
    get First(): number;
    set First(value: number);
    get Length(): number;
    set Length(value: number);
    equals(cr: CharacterRange): boolean;
}
