import { int, Out, EventArgs, IntPtr, float, IntArray } from '@tuval/core';
import { BrushType, Status, ImageType } from './gdipEnums';
import { CGPoint, CGRectangle, CGImage, IContext2D } from '@tuval/cg';
import { CombineMode } from './drawing2D/CombineMode';
import { Stream } from '../index_web';
import { GdiplusStartupInput, GdiplusStartupOutput, GdipPropertyItem } from './gdipStructs';
import { Guid, uint, Delegate, ByteArray, Dictionary } from '@tuval/core';
import { GraphicsUnit } from './GraphicsUnit';
import { RotateFlipType } from './RotateFlipType';
import { StringFormatFlags } from './StringFormatFlags';
import { PixelFormat } from './imaging/PixelFormat';
import { ImageLockMode } from './imaging/ImageLockMode';
import { BitmapData } from './imaging/BitmapData';
export declare class DrawImageAbort extends Delegate<(callbackData: IntPtr) => boolean> {
}
export declare class ImageHandleTable extends Dictionary<IntPtr, CGImage> {
    private static handleCount;
    CreateHandle(image: CGImage): IntPtr;
    GetImage(handle: IntPtr): CGImage;
}
export declare class GraphicsHandleTable extends Dictionary<IntPtr, IContext2D> {
    static Default: GraphicsHandleTable;
    private static handleCount;
    CreateHandle(context: IContext2D): IntPtr;
    GetGraphics(handle: IntPtr): IContext2D;
    SetGraphics(handle: IntPtr, renderingContext: IContext2D): void;
}
export declare class GDIPlus {
    static ImageHandleTable: ImageHandleTable;
    static readonly FACESIZE: int;
    static readonly LANG_NEUTRAL: int;
    static Display: IntPtr;
    static UseX11Drawable: boolean;
    static UseCarbonDrawable: boolean;
    static UseCocoaDrawable: boolean;
    static GdiplusStartup(token: Out<int>, input: Out<GdiplusStartupInput>, output: Out<GdiplusStartupOutput>): Status;
    static GdiplusShutdown(token: Out<int>): void;
    static GdiPlusToken: Out<int>;
    static ProcessExit(sender: any, e: EventArgs): void;
    static StaticConstructor(): void;
    static RunningOnWindows(): boolean;
    static RunningOnUnix(): boolean;
    static FromUnManagedMemoryToPointI(prt: IntPtr, pts: CGPoint[]): void;
    static FromUnManagedMemoryToPoint(prt: IntPtr, pts: CGPoint[]): void;
    static FromPointToUnManagedMemoryI(pts: CGPoint[]): IntPtr;
    static FromUnManagedMemoryToRectangles(prt: IntPtr, pts: CGRectangle[]): void;
    static FromPointToUnManagedMemory(pts: CGPoint[]): IntPtr;
    static CheckStatus(status: Status): void;
    static GdipAlloc(size: int): IntPtr;
    static GdipFree(ptr: IntPtr): void;
    static GdipCloneBrush(brush: IntPtr, clonedBrush: Out<IntPtr>): Status;
    static GdipDeleteBrush(brush: IntPtr): Status;
    static GdipGetBrushType(brush: IntPtr, type: Out<BrushType>): Status;
    static GdipCreateRegion(region: Out<IntPtr>): Status;
    static GdipCreateRegionRgnData(data: ByteArray, size: int, region: Out<IntPtr>): Status;
    static GdipDeleteRegion(region: IntPtr): Status;
    static GdipCloneRegion(region: IntPtr, cloned: Out<IntPtr>): Status;
    static GdipCreateRegionRect(rect: Out<CGRectangle>, region: Out<IntPtr>): Status;
    static GdipCreateRegionRectI(rect: Out<CGRectangle>, region: Out<IntPtr>): Status;
    static GdipCreateRegionPath(path: IntPtr, region: Out<IntPtr>): Status;
    static GdipTranslateRegion(region: IntPtr, dx: float, dy: float): Status;
    static GdipTranslateRegionI(region: IntPtr, dx: int, dy: int): Status;
    static GdipIsVisibleRegionPoint(region: IntPtr, x: float, y: float, graphics: IntPtr, result: Out<boolean>): Status;
    static GdipIsVisibleRegionPointI(region: IntPtr, x: int, y: int, graphics: IntPtr, result: Out<boolean>): Status;
    static GdipIsVisibleRegionRect(region: IntPtr, x: float, y: float, width: float, height: float, graphics: IntPtr, result: Out<boolean>): Status;
    static GdipIsVisibleRegionRectI(region: IntPtr, x: int, y: int, width: int, height: int, graphics: IntPtr, result: Out<boolean>): Status;
    static GdipCombineRegionRect(region: IntPtr, rect: Out<CGRectangle>, combineMode: CombineMode): Status;
    static GdipCombineRegionRectI(region: IntPtr, rect: Out<CGRectangle>, combineMode: CombineMode): Status;
    static GdipCombineRegionPath(region: IntPtr, path: IntPtr, combineMode: CombineMode): Status;
    static GdipGetRegionBounds(region: IntPtr, graphics: IntPtr, rect: Out<CGRectangle>): Status;
    static GdipSetInfinite(region: IntPtr): Status;
    static GdipSetEmpty(region: IntPtr): Status;
    static GdipIsEmptyRegion(region: IntPtr, graphics: IntPtr, result: Out<boolean>): Status;
    static GdipIsInfiniteRegion(region: IntPtr, graphics: IntPtr, result: Out<boolean>): Status;
    static GdipCombineRegionRegion(region: IntPtr, region2: IntPtr, combineMode: CombineMode): Status;
    static GdipIsEqualRegion(region: IntPtr, region2: IntPtr, graphics: IntPtr, result: Out<boolean>): Status;
    static GdipCloneBitmapArea(x: float, y: float, width: float, height: float, format: PixelFormat, original: IntPtr, bitmap: Out<IntPtr>): Status;
    static GdipLoadImageFromFile(filename: string, image: Out<IntPtr>): Status;
    static GdipLoadImageFromStream(stream: Stream, image: Out<IntPtr>): Status;
    static GdipSaveImageToStream(image: IntPtr, stream: Stream, clsidEncoder: Out<Guid>, encoderParams: IntPtr): Status;
    static GdipCloneImage(image: IntPtr, imageclone: Out<IntPtr>): Status;
    static GdipLoadImageFromFileICM(filename: string, image: IntPtr): Status;
    static GdipCreateBitmapFromHBITMAP(hBitMap: IntPtr, gdiPalette: IntPtr, image: Out<IntPtr>): Status;
    static GdipDisposeImage(image: IntPtr): Status;
    static GdipGetImageFlags(image: IntPtr, flag: Out<int>): Status;
    static GdipGetImageType(image: IntPtr, type: Out<ImageType>): Status;
    static GdipImageGetFrameDimensionsCount(image: IntPtr, count: Out<uint>): Status;
    static GdipImageGetFrameDimensionsList(image: IntPtr, dimensionIDs: Guid[], count: uint): Status;
    static GdipGetImageHeight(image: IntPtr, height: Out<uint>): Status;
    static GdipGetImageHorizontalResolution(image: IntPtr, resolution: Out<float>): Status;
    static GdipGetImagePaletteSize(image: IntPtr, size: Out<int>): Status;
    static GdipGetImagePalette(image: IntPtr, palette: IntPtr, size: int): Status;
    static GdipSetImagePalette(image: IntPtr, palette: IntPtr): Status;
    static GdipGetImageDimension(image: IntPtr, width: Out<float>, height: Out<float>): Status;
    static GdipGetImagePixelFormat(image: IntPtr, format: Out<PixelFormat>): Status;
    static GdipGetPropertyCount(image: IntPtr, propNumbers: Out<uint>): Status;
    static GdipGetPropertyIdList(image: IntPtr, propNumbers: uint, list: IntArray): Status;
    static GdipGetPropertySize(image: IntPtr, bufferSize: Out<int>, propNumbers: Out<int>): Status;
    static GdipGetAllPropertyItems(image: IntPtr, bufferSize: int, propNumbers: int, items: IntPtr): Status;
    static GdipGetImageRawFormat(image: IntPtr, format: Out<Guid>): Status;
    static GdipGetImageVerticalResolution(image: IntPtr, resolution: Out<float>): Status;
    static GdipGetImageWidth(image: IntPtr, width: Out<uint>): Status;
    static GdipGetImageBounds(image: IntPtr, source: Out<CGRectangle>, unit: Out<GraphicsUnit>): Status;
    static GdipGetEncoderParameterListSize(image: IntPtr, encoder: Out<Guid>, size: Out<uint>): Status;
    static GdipGetEncoderParameterList(image: IntPtr, encoder: Out<Guid>, size: uint, buffer: IntPtr): Status;
    static GdipImageGetFrameCount(image: IntPtr, guidDimension: Out<Guid>, count: Out<uint>): Status;
    static GdipImageSelectActiveFrame(image: IntPtr, guidDimension: Out<Guid>, frameIndex: int): Status;
    static GdipGetPropertyItemSize(image: IntPtr, propertyID: int, propertySize: Out<int>): Status;
    static GdipGetPropertyItem(image: IntPtr, propertyID: int, propertySize: int, buffer: IntPtr): Status;
    static GdipRemovePropertyItem(image: IntPtr, propertyId: int): Status;
    static GdipSetPropertyItem(image: IntPtr, propertyItem: GdipPropertyItem): Status;
    static GdipGetImageThumbnail(image: IntPtr, width: uint, height: uint, thumbImage: Out<IntPtr>, callback: IntPtr, callBackData: IntPtr): Status;
    static GdipImageRotateFlip(image: IntPtr, rotateFlipType: RotateFlipType): Status;
    static GdipSaveImageToFile(image: IntPtr, filename: string, encoderClsID: Out<Guid>, encoderParameters: IntPtr): Status;
    static GdipSaveAdd(image: IntPtr, encoderParameters: IntPtr): Status;
    static GdipSaveAddImage(image: IntPtr, imagenew: IntPtr, encoderParameters: IntPtr): Status;
    static GdipDrawImageI(graphics: IntPtr, image: IntPtr, x: int, y: int): Status;
    static GdipGetImageGraphicsContext(image: IntPtr, graphics: Out<IntPtr>): Status;
    static GdipDrawImage(graphics: IntPtr, image: IntPtr, x: float, y: float): Status;
    static GdipBeginContainer(graphics: IntPtr, dstrect: Out<CGRectangle>, srcrect: Out<CGRectangle>, unit: GraphicsUnit, state: Out<uint>): Status;
    static GdipBeginContainerI(graphics: IntPtr, dstrect: Out<CGRectangle>, srcrect: Out<CGRectangle>, unit: GraphicsUnit, state: Out<uint>): Status;
    static GdipBeginContainer2(graphics: IntPtr, state: Out<uint>): Status;
    static GdipDrawImagePoints(graphics: IntPtr, image: IntPtr, destPoints: CGPoint[], count: int): Status;
    static GdipDrawImagePointsI(graphics: IntPtr, image: IntPtr, destPoints: CGPoint[], count: int): Status;
    static GdipDrawImageRectRectI(graphics: IntPtr, image: IntPtr, dstx: int, dsty: int, dstwidth: int, dstheight: int, srcx: int, srcy: int, srcwidth: int, srcheight: int, srcUnit: GraphicsUnit, imageattr: IntPtr, callback: DrawImageAbort, callbackData: IntPtr): Status;
    static GdipDrawImageRectRect(graphics: IntPtr, image: IntPtr, dstx: float, dsty: float, dstwidth: float, dstheight: float, srcx: float, srcy: float, srcwidth: float, srcheight: float, srcUnit: GraphicsUnit, imageattr: IntPtr, callback: DrawImageAbort, callbackData: IntPtr): Status;
    static GdipDrawImagePointsRectI(graphics: IntPtr, image: IntPtr, destPoints: CGPoint, count: int, srcx: int, srcy: int, srcwidth: int, srcheight: int, srcUnit: GraphicsUnit, imageattr: IntPtr, callback: DrawImageAbort, callbackData: IntPtr): Status;
    static GdipDrawImagePointsRect(graphics: IntPtr, image: IntPtr, destPoints: CGPoint[], count: int, srcx: float, srcy: float, srcwidth: float, srcheight: float, srcUnit: GraphicsUnit, imageattr: IntPtr, callback: DrawImageAbort, callbackData: IntPtr): Status;
    static GdipDrawImageRect(graphics: IntPtr, image: IntPtr, x: float, y: float, width: float, height: float): Status;
    static GdipDrawImagePointRect(graphics: IntPtr, image: IntPtr, x: float, y: float, srcx: float, srcy: float, srcwidth: float, srcheight: float, srcUnit: GraphicsUnit): Status;
    static GdipDrawImagePointRectI(graphics: IntPtr, image: IntPtr, x: int, y: int, srcx: int, srcy: int, srcwidth: int, srcheight: int, srcUnit: GraphicsUnit): Status;
    static GdipCreateStringFormat(formatAttributes: StringFormatFlags, language: int, native: Out<IntPtr>): Status;
    static GdipCreateHBITMAPFromBitmap(bmp: IntPtr, HandleBmp: Out<IntPtr>, clrbackground: int): Status;
    static GdipCreateBitmapFromFile(filename: string, bitmap: Out<IntPtr>): Status;
    static GdipCreateBitmapFromFileICM(filename: string, bitmap: Out<IntPtr>): Status;
    static GdipCreateHICONFromBitmap(bmp: IntPtr, HandleIcon: Out<IntPtr>): Status;
    static GdipCreateBitmapFromHICON(hicon: IntPtr, bitmap: Out<IntPtr>): Status;
    static GdipCreateBitmapFromResource(hInstance: IntPtr, lpBitmapName: string, bitmap: Out<IntPtr>): Status;
    static GdipGetImageDecodersSize(decoderNums: Out<int>, arraySize: Out<int>): Status;
    static GdipGetImageDecoders(decoderNums: int, arraySize: int, decoders: IntPtr): Status;
    static GdipGetImageEncodersSize(encoderNums: Out<int>, arraySize: Out<int>): Status;
    static GdipGetImageEncoders(encoderNums: int, arraySize: int, encoders: IntPtr): Status;
    static GdipCreateBitmapFromScan0(width: int, height: int, stride: int, format: PixelFormat, scan0: IntPtr, bmp: Out<IntPtr>): Status;
    static GdipCreateBitmapFromGraphics(width: int, height: int, target: IntPtr, bitmap: Out<IntPtr>): Status;
    static GdipBitmapLockBits(bmp: IntPtr, rc: Out<CGRectangle>, flags: ImageLockMode, format: PixelFormat, bmpData: BitmapData): Status;
    static GdipBitmapSetResolution(bmp: IntPtr, xdpi: float, ydpi: float): Status;
    static GdipBitmapUnlockBits(bmp: IntPtr, bmpData: BitmapData): Status;
    static GdipBitmapGetPixel(bmp: IntPtr, x: int, y: int, argb: Out<int>): Status;
    static GdipBitmapSetPixel(bmp: IntPtr, x: int, y: int, argb: int): Status;
}
export declare class StreamGetHeaderDelegate extends Delegate<(buf: IntPtr, bufsz: int) => int> {
}
export declare class StreamGetBytesDelegate extends Delegate<(buf: IntPtr, bufsz: int, peek: boolean) => int> {
}
export declare class StreamSeekDelegate extends Delegate<(offset: int, whence: int) => int> {
}
export declare class StreamPutBytesDelegate extends Delegate<(buf: IntPtr, bufsz: int) => int> {
}
export declare class StreamCloseDelegate extends Delegate<() => void> {
}
export declare class StreamSizeDelegate extends Delegate<() => int> {
}
export declare class GdiPlusStreamHelper {
    stream: Stream;
    private sghd;
    private sgbd;
    private skd;
    private spbd;
    private scd;
    private ssd;
    private start_buf;
    private start_buf_pos;
    private start_buf_len;
    private managedBuf;
    private static readonly default_bufsize;
    constructor(s: Stream, seekToOrigin: boolean);
    StreamGetHeaderImpl(buf: IntPtr, bufsz: int): int;
    get GetHeaderDelegate(): StreamGetHeaderDelegate;
    StreamGetBytesImpl(buf: IntPtr, bufsz: int, peek: boolean): int;
    get GetBytesDelegate(): StreamGetBytesDelegate;
    StreamSeekImpl(offset: int, whence: int): int;
    get SeekDelegate(): StreamSeekDelegate;
    StreamPutBytesImpl(buf: IntPtr, bufsz: int): int;
    get PutBytesDelegate(): StreamPutBytesDelegate;
    StreamCloseImpl(): void;
    get CloseDelegate(): StreamCloseDelegate;
    StreamSizeImpl(): int;
    get SizeDelegate(): StreamSizeDelegate;
}
