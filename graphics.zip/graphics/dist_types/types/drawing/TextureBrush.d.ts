import { CGImage } from '@tuval/cg';
import { Brush } from './Brush';
import { Matrix, MatrixOrder } from './drawing2D/Matrix';
import { WrapMode } from './drawing2D/WrapMode';
import { float } from '@tuval/core';
import { Graphics } from './Graphics';
export declare class TextureBrush extends Brush {
    private textureImage;
    private textureTransform;
    private wrapMode;
    private _changed;
    get Image(): CGImage | HTMLImageElement;
    get Transform(): Matrix;
    set Transform(value: Matrix);
    get WrapMode(): WrapMode;
    set WrapMode(value: WrapMode);
    constructor(image: CGImage);
    multiplyTransform(matrix: Matrix, order?: MatrixOrder): void;
    resetTransform(): void;
    rotateTransform(angle: float): void;
    scaleTransform(sx: float, sy: float, order?: MatrixOrder): void;
    translateTransform(dx: float, dy: float, order?: MatrixOrder): void;
    private drawTexture;
    setup(graphics: Graphics, fill: boolean): void;
}
