export declare enum StringAlignment {
    Near = 0,
    Center = 1,
    Far = 2
}
