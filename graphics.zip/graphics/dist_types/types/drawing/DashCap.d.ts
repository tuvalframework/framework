export declare enum DashCap {
    Flat = 0,
    Round = 2,
    Triangle = 3
}
