export declare enum LineJoin {
    Miter = 0,
    Bevel = 1,
    Round = 2,
    MiterClipped = 3
}
