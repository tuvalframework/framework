export declare enum FlushIntention {
    Flush = 0,
    Sync = 1
}
