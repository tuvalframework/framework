export declare enum LinearGradientMode {
    Horizontal = "Horizontal",
    Vertical = "Vertical",
    ForwardDiagonal = "ForwardDiagonal",
    BackwardDiagonal = "BackwardDiagonal"
}
