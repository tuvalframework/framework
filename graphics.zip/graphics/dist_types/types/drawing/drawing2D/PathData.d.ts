import { CGPoint } from '@tuval/cg';
import { byte } from "@tuval/core";
export declare class PathData {
    Points: CGPoint[];
    Types: byte[];
    constructor(points: CGPoint[], types: byte[]);
}
