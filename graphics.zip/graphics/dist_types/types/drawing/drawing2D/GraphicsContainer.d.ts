export declare class GraphicsContainer {
    private nativeGraphicsContainer;
    constructor(graphicsContainer: number);
}
