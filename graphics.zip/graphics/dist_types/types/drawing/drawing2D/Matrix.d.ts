import { CGAffineTransform, CGRectangle, CGPoint } from "@tuval/cg";
import { IDisposable, float } from "@tuval/core";
export declare enum MatrixOrder {
    Prepend = 0,
    Append = 1
}
export declare class Matrix implements IDisposable {
    transform: CGAffineTransform;
    constructor();
    constructor(transform: CGAffineTransform);
    constructor(rect: CGRectangle, plgpts: CGPoint[]);
    constructor(m11: float, m12: float, m21: float, m22: float, dx: float, dy: float);
    get Elements(): float[];
    get IsIdentity(): boolean;
    get IsInvertible(): boolean;
    get OffsetX(): float;
    get OffsetY(): float;
    get IsScaled(): boolean;
    clone(): Matrix;
    Dispose(): void;
    equals(m: Matrix): boolean;
    getHashCode(): number;
    invert(): void;
    multiply(matrix: Matrix): void;
    multiply(matrix: Matrix, order: MatrixOrder): void;
    reset(): void;
    rotate(angle: float): void;
    rotate(angle: float, order: MatrixOrder): void;
    rotateAt(angle: float, point: CGPoint): void;
    rotateAt(angle: float, point: CGPoint, order: MatrixOrder): void;
    scale(scaleX: float, scaleY: float): void;
    scale(scaleX: float, scaleY: float, order: MatrixOrder): void;
    shear(shearX: float, shearY: float): void;
    shear(shearX: float, shearY: float, order: MatrixOrder): void;
    transformPoints(pts: CGPoint[]): void;
    transformVectors(pts: CGPoint[]): void;
    translate(offsetX: float, offsetY: float): void;
    translate(offsetX: float, offsetY: float, order: MatrixOrder): void;
    vectorTransformPoints(pts: CGPoint[]): void;
}
