import { CGColor } from "@tuval/cg";
import { float } from "@tuval/core";
export declare class ColorBlend {
    Colors: CGColor[];
    Positions: float[];
    constructor(count?: number);
}
