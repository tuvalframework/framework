import { CGPoint } from '@tuval/cg';
import { GraphicsPath } from "./GraphicsPath";
import { byte, Out } from "@tuval/core";
export declare class GraphicsPathIterator {
    private path;
    private markerPosition;
    private subpathPosition;
    private pathTypePosition;
    constructor(path: GraphicsPath);
    get Count(): number;
    get SubpathCount(): number;
    dispose(disposing: boolean): void;
    copyData(points: Out<CGPoint[]>, types: Out<byte[]>, startIndex: number, endIndex: number): number;
    enumerate(points: Out<CGPoint[]>, types: Out<byte[]>): number;
    hasCurve(): boolean;
    nextMarker(path: GraphicsPath): number;
    NextMarker1(startIndex: Out<number>, endIndex: Out<number>): number;
    nextPathType(pathType: Out<byte>, startIndex: Out<byte>, endIndex: Out<number>): number;
    nextSubpath(path: GraphicsPath, isClosed: Out<boolean>): number;
    nextSubpath1(startIndex: Out<number>, endIndex: Out<number>, isClosed: Out<boolean>): number;
    rewind(): void;
}
