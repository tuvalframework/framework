import { CGPoint } from '@tuval/cg';
import { GraphicsPath } from "./GraphicsPath";
export declare class HitTester {
    private myGraphicsPath;
    constructor(graphicsPath: GraphicsPath);
    private plotPath;
    test(point: CGPoint): boolean;
}
