import { CGPoint } from '@tuval/cg';
import { Pen } from "../Pen";
import { Brush } from "../Brush";
import { Matrix } from "./Matrix";
import { GraphicsUnit } from "../GraphicsUnit";
import { SmoothingMode } from "../SmoothingMode";
import { Region } from "../Region";
import { float } from "@tuval/core";
export declare class GraphicsState {
    lastPen: Pen;
    lastBrush: Brush;
    model: Matrix;
    view: Matrix;
    renderingOrigin: CGPoint;
    pageUnit: GraphicsUnit;
    pageScale: float;
    smoothingMode: SmoothingMode;
    clipRegion: Region;
}
