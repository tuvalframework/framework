export declare enum CompositingQuality {
    Invalid = -1,
    Default = 0,
    HighSpeed = 1,
    HighQuality = 2,
    GammaCorrected = 3,
    AssumeLinear = 4
}
