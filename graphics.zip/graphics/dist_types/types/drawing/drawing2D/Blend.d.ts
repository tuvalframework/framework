import { float } from "@tuval/core";
export declare class Blend {
    Factors: float[];
    Positions: float[];
    constructor(count?: number);
}
