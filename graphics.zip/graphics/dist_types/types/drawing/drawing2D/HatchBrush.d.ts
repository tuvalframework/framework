import { CGColor } from '@tuval/cg';
import { Brush } from "../Brush";
import { HatchStyle } from "./HatchStyle";
import { Graphics } from "../Graphics";
export declare class HatchBrush extends Brush {
    private backColor;
    private foreColor;
    private hatchStyle;
    private getHatchWidth;
    private getHatchHeight;
    private getLineWidth;
    private drawBackground;
    private initializeContext;
    constructor(hatchStyle: HatchStyle, foreColor: CGColor);
    constructor(hatchStyle: HatchStyle, foreColor: CGColor, backColor: CGColor);
    get BackgroundColor(): CGColor;
    get ForegroundColor(): CGColor;
    get HatchStyle(): HatchStyle;
    Clone(): HatchBrush;
    private hatchHorizontal;
    private hatchVertical;
    private hatchGrid;
    /**
     * Percentage patterns were obtained by creating a screen shot from a windows fill
     * and looking at the patterns at the pixel level.  A little tedious to say the least
     * but they do seem correct and recreate the same pattern from windows to here.
     */
    private hatchPercentage;
    private hatchUpwardDiagonal;
    private hatchDiagonalCross;
    /**
     * This is fill of hackish stuff.
     * Thought this was going to be easier but that just did not work out.
     **/
    private hatchSphere;
    private hatchDashedDiagonal;
    private hatchDashedHorizontal;
    private hatchConfetti;
    private hatchZigZag;
    private hatchWave;
    private hatchHorizontalBrick;
    private hatchDiagonalBrick;
    private hatchWeave;
    private hatchTrellis;
    private hatchCheckered;
    private hatchOutlinedDiamond;
    private hatchSolidDiamond;
    private hatchDottedDiamond;
    private hatchShingle;
    private hatchDivot;
    private hatchPlaid;
    private setPixels;
    private drawPolkaDotPattern;
    setup(graphics: Graphics, fill: boolean): void;
}
