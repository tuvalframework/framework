import { CGRectangle, CGPoint } from '@tuval/cg';
import { List } from "@tuval/core";
import { GraphicsPath } from "./drawing2D/GraphicsPath";
import { float } from "@tuval/core";
import { Graphics } from "./Graphics";
import { Matrix } from "./drawing2D/Matrix";
import { Paths, Path } from "./Clipper";
export declare enum RegionType {
    Rectangle = 10000,
    Infinity = 10001,
    Empty = 10002,
    Path = 10003
}
export declare enum RegionClipType {
    Intersection = 0,
    Union = 1,
    Difference = 2,
    Xor = 3,
    None = -1
}
declare class RegionEntry {
    regionType: RegionType;
    regionObject: any;
    regionPath: Paths;
    regionClipType: RegionClipType;
    constructor1(type: RegionType): void;
    constructor2(type: RegionType, obj: any): void;
    constructor3(type: RegionType, obj: any, path: Path): void;
    constructor();
    constructor(type: RegionType, obj: any, path: Path, clipType: RegionClipType);
    constructor(type: RegionType, obj: any, path: Paths, clipType: RegionClipType);
}
export declare class Region {
    private static readonly SUBJ_FILL_TYPE;
    private static readonly CLIP_FILL_TYPE;
    static infinite: CGRectangle;
    regionObject: any;
    regionList: List<RegionEntry>;
    regionPath: GraphicsPath;
    regionBounds: CGRectangle;
    private static scale;
    solution: Paths;
    constructor(region: Region);
    constructor(path: GraphicsPath);
    constructor(rect: CGRectangle);
    constructor();
    static PointFArrayToIntArray(points: CGPoint[], scale: float): Path;
    static PathToPointFArray(pg: Path, scale: float): CGPoint[];
    equals(region: Region, g: Graphics): boolean;
    clone(): Region;
    static Copy(src: Paths): Paths;
    static Copy1(src: List<RegionEntry>): List<RegionEntry>;
    static CopyRegionObject(src: CGRectangle | GraphicsPath): CGRectangle | GraphicsPath;
    getBounds(): CGRectangle;
    getBounds(g: Graphics): CGRectangle;
    makeInfinite(): void;
    makeEmpty(): void;
    transform(matrix: Matrix): void;
    private static TransformIntPoint;
    translate(dx: float, dy: float): void;
    intersect(path: GraphicsPath): void;
    intersect(region: Region): void;
    intersect(rect: CGRectangle): void;
    dispose(): void;
    union(rect: CGRectangle): void;
    union(region: Region): void;
    union(path: GraphicsPath): void;
    xor(rect: CGRectangle): void;
    xor(region: Region): void;
    xor(path: GraphicsPath): void;
    exclude(rect: CGRectangle): void;
    exclude(region: Region): void;
    exclude(path: GraphicsPath): void;
    private calculateRegionPath;
    private pathsToInternalPath;
    isInfinite(g: Graphics): boolean;
    isVisible(x: float, y: float): boolean;
    isVisible(point: CGPoint): boolean;
    isEmpty(g: Graphics): boolean;
    private static RectangleToPath;
    private static IntPointToPointF;
    getRegionScans(matrix: Matrix): CGRectangle[];
    private static NotImplemented;
}
export {};
