import { CGColor } from '@tuval/cg';
import { Brush } from "./Brush";
import { Graphics } from "./Graphics";
export declare class SolidBrush extends Brush {
    private color;
    isModifiable: boolean;
    private isModified;
    constructor(color: CGColor, isModifiable?: boolean);
    get Color(): CGColor;
    set Color(value: CGColor);
    Dispose(disposing?: boolean): void;
    Clone(): SolidBrush;
    setup(graphics: Graphics, fill: boolean): void;
    equals(sb: SolidBrush): boolean;
    getHashCode(): number;
}
