import { FontStyle } from "./FontStyle";
export declare class FontFamily {
    private familyName;
    get Name(): string;
    getLineSpacing(style: FontStyle): number;
    getEmHeight(style: FontStyle): number;
    constructor(name: string);
    toString(): string;
}
