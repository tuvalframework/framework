import { Tween } from './scene/tween/Tween';
import { Pen } from "./Pen";
import { Brush } from "./Brush";
import { CGRectangle, IContext2D, CGColor, CGPoint, CGSize, CGContext2D, CGCommandContext2D } from "@tuval/cg";
import { GraphicsUnit } from "./GraphicsUnit";
import { InterpolationMode } from "./InterpolationMode";
import { SmoothingMode } from "./SmoothingMode";
import { Matrix, MatrixOrder } from "./drawing2D/Matrix";
import { float, Out, byte, int, TObject, IntPtr } from '@tuval/core';
import { Region } from "./Region";
import { FillMode } from "./drawing2D/FillMode";
import { GraphicsPath } from "./drawing2D/GraphicsPath";
import { CombineMode } from "./drawing2D/CombineMode";
import { GraphicsContainer } from "./drawing2D/GraphicsContainer";
import { PixelOffsetMode } from "./drawing2D/PixelOffsetMode";
import { CompositingQuality } from "./drawing2D/CompositingQuality";
import { GraphicsState } from "./drawing2D/GraphicsState";
import { FlushIntention } from "./drawing2D/FlushIntention";
import { CoordinateSpace } from "./drawing2D/CoordinateSpace";
import { Font } from "./Font";
import { StringFormat } from "./StringFormat";
import { SolidBrush } from "./SolidBrush";
import { ImageAttributes } from "./imaging/ImageAttributes";
import { Image } from "./Image";
export declare enum AngleModes {
    Degrees = "degrees",
    Radians = "radians"
}
export declare enum EllipseModes {
    Radians = "radians",
    Corner = "corner",
    Corners = "corners",
    Center = "center"
}
export declare enum RectangleModes {
    Radians = "radians",
    Corner = "corner",
    Corners = "corners",
    Center = "center"
}
export declare enum ArcModes {
    Chord = "chord",
    Pie = "pie",
    Open = "open"
}
export declare enum CompositingMode {
    SourceOver = 0,
    SourceCopy = 1
}
export interface TextMetricsEx {
    width: number;
    fontSize: number;
    leading: number;
    ascent: number;
    descent: number;
    bounds: any;
    height: number;
}
export declare const PI: number;
export declare const DEG_TO_RAD: number;
export declare const RAD_TO_DEG: number;
export declare const TWO_PI: number;
export declare const HALF_PI: number;
export declare const QUARTER_PI: number;
export declare const CORNER = "corner";
export declare const CORNERS = "corners";
export declare abstract class GraphicsBase<T extends IContext2D> extends TObject {
    nativeObject: IntPtr;
    private ticker;
    renderer: T;
    private hasClientTransform;
    LastPen: Pen;
    LastBrush: Brush;
    private boundingBox;
    private quartzUnit;
    protected isFlipped: boolean;
    private interpolationMode;
    private myAngleMode;
    private myEllipseMode;
    x: number;
    y: number;
    width: number;
    height: number;
    private smoothingMode;
    LastBrushColor: CGColor;
    modelMatrix: Matrix;
    private viewMatrix;
    private modelViewMatrix;
    private userspaceScaleX;
    private userspaceScaleY;
    private graphicsUnit;
    private pageScale;
    private renderingOrigin;
    private subviewClipOffset;
    private static infiniteRegion;
    private clip;
    protected screenScale: float;
    private compositing_mode;
    private static maxSize;
    private static readonly DrawStringCacheCapacity;
    private static DrawStringCache;
    private static MeasureStringCache;
    constructor();
    private myCurrentPen;
    get CurrentPen(): Pen;
    set CurrentPen(value: Pen);
    protected getCurrentPen(): Pen;
    protected setCurrentPen(value: Pen): void;
    private myCurrentBrush;
    get CurrentBrush(): Brush;
    set CurrentBrush(value: Brush);
    protected getCurrentBrush(): Brush;
    protected setCurrentBrush(value: Brush): void;
    setSize(width: int, height: int): void;
    abstract provideRenderer2D(): T;
    abstract init(): void;
    get CompositingMode(): CompositingMode;
    set CompositingMode(value: CompositingMode);
    Graphics(context: CanvasRenderingContext2D, flipped: boolean): void;
    Graphics(context: CGContext2D, flipped: boolean): void;
    DeltaTime: int;
    FPS: int;
    MemoryUsage: int;
    private totalFPS;
    private totalFPSCount;
    private AvgFPS;
    FrameCount: int;
    private prevFPS;
    private begin;
    private end;
    CreateTween(obj: any, props?: any): Tween;
    UpdateTween(event: any): void;
    RequestAnimationFrame(func: Function): void;
    private modeAdjust;
    protected initializeContext(context: IContext2D): void;
    private initializeMatrix;
    private graphicsUnitConvertX;
    private graphicsUnitConvertY;
    dispose(disposing?: boolean): void;
    transferToImageBitmap(): ImageBitmap;
    moveTo(point: CGPoint): void;
    moveTo(x: float, y: float): void;
    lineTo(point: CGPoint): void;
    lineTo(x: float, y: float): void;
    curveTo(x1: float, y1: float, x2: float, y2: float, x3: float, y3: float): void;
    preparePen(pen: Pen): void;
    private strokePen;
    private fillBrush;
    drawArc(pen: Pen, rect: CGRectangle, startAngle: float, sweepAngle: float): void;
    drawArc(pen: Pen, x: float, y: float, width: float, height: float, startAngle: float, sweepAngle: float): void;
    DrawLine(pen: Pen, pt1: CGPoint, pt2: CGPoint): void;
    DrawLine(pen: Pen, x1: float, y1: float, x2: float, y2: float): void;
    drawBezier(pen: Pen, pt1: CGPoint, pt2: CGPoint, pt3: CGPoint, pt4: CGPoint): void;
    drawBezier(pen: Pen, x1: float, y1: float, x2: float, y2: float, x3: float, y3: float, x4: float, y4: float): void;
    drawBeziers(pen: Pen, points: CGPoint[]): void;
    drawLines(pen: Pen, points: CGPoint[]): void;
    private rectanglePath;
    DrawRectangle(pen: Pen, rect: CGRectangle, mode?: RectangleModes): void;
    DrawRectangle(pen: Pen, rect: CGRectangle, tl: number, tr?: number, br?: number, bl?: number, mode?: RectangleModes): void;
    DrawRectangle(pen: Pen, x1: float, y1: float, w: float, h: float, mode?: RectangleModes): void;
    DrawRectangle(pen: Pen, x1: float, y1: float, w: float, h: float, tl: number, tr?: number, br?: number, bl?: number, mode?: RectangleModes): void;
    FillRectangle(brush: Brush, rect: CGRectangle, mode?: RectangleModes): void;
    FillRectangle(brush: Brush, rect: CGRectangle, tl: number, tr?: number, br?: number, bl?: number, mode?: RectangleModes): void;
    FillRectangle(brush: Brush, x1: float, y1: float, w: float, h: float, mode?: RectangleModes): void;
    FillRectangle(brush: Brush, x1: float, y1: float, w: float, h: float, tl: number, tr?: number, br?: number, bl?: number, mode?: RectangleModes): void;
    fillRegion(brush: Brush, region: Region): void;
    private makeEllipse;
    drawPoint(pen: Pen, point: CGPoint): void;
    drawPoint(pen: Pen, x: number, y: number): void;
    DrawEllipse(pen: Pen, rect: CGRectangle): void;
    DrawEllipse(pen: Pen, x: float, y: float, radius: float, ellipseMode?: EllipseModes): void;
    DrawEllipse(pen: Pen, x: float, y: float, width: float, height: float, ellipseMode?: EllipseModes): void;
    FillEllipse(pen: Brush, rect: CGRectangle): void;
    FillEllipse(pen: Brush, x: float, y: float, radius: float, ellipseMode?: EllipseModes): void;
    FillEllipse(pen: Brush, x: float, y: float, width: float, height: float, ellipseMode?: EllipseModes): void;
    private applyModelgetView;
    resetTransform(): void;
    get Transform(): Matrix;
    set Transform(value: Matrix);
    rotateTransform(angle: float): void;
    rotateTransform(angle: float, order: MatrixOrder): void;
    translateTransform(tx: float, ty: float): void;
    translateTransform(tx: float, ty: float, order: MatrixOrder): void;
    ScaleTransform(sx: float, sy: float): void;
    ScaleTransform(sx: float, sy: float, order: MatrixOrder): void;
    private makeCurve;
    drawCurve(pen: Pen, points: CGPoint[]): void;
    drawCurve(pen: Pen, points: CGPoint[], tension: float): void;
    drawCurve(pen: Pen, points: CGPoint[], offset: number, numberOfSegments: number, tension: float): void;
    private plotPath;
    drawContextPath(pen: Pen): void;
    drawPath(pen: Pen, path: GraphicsPath): void;
    fillContextPath(brush: Brush): void;
    fillPath(brush: Brush, path: GraphicsPath): void;
    getNearestColor(color: CGColor): CGColor;
    private setupgetView;
    get PageUnit(): GraphicsUnit;
    set PageUnit(value: GraphicsUnit);
    get PageScale(): float;
    set PageScale(value: float);
    setClip(rect: CGRectangle): void;
    setClip(graphicsPath: GraphicsPath): void;
    setClip(g: Graphics): void;
    setClip(rect: CGRectangle, combineMode: CombineMode): void;
    setClip(graphicsPath: GraphicsPath, combineMode: CombineMode): void;
    setClip(g: Graphics, combineMode: CombineMode): void;
    setClip(region: Region, combineMode: CombineMode): void;
    beginContainer(dstRect: CGRectangle, srcRect: CGRectangle, unit: GraphicsUnit): GraphicsContainer;
    endContainer(container: GraphicsContainer): void;
    get SmoothingMode(): SmoothingMode;
    set SmoothingMode(value: SmoothingMode);
    get IsClipEmpty(): boolean;
    get PixelOffsetMode(): PixelOffsetMode;
    set PixelOffsetMode(value: PixelOffsetMode);
    get Clip(): Region;
    set Clip(value: Region);
    get ClipBounds(): CGRectangle;
    set ClipBounds(value: CGRectangle);
    get VisibleClipBounds(): CGRectangle;
    set VisibleClipBounds(value: CGRectangle);
    get InterpolationMode(): InterpolationMode;
    set InterpolationMode(value: InterpolationMode);
    get RenderingOrigin(): CGPoint;
    set RenderingOrigin(value: CGPoint);
    get TextContrast(): number;
    set TextContrast(value: number);
    get DpiX(): float;
    get DpiY(): float;
    get CompositingQuality(): CompositingQuality;
    get isVisibleClipEmpty(): boolean;
    translateClip(dx: float, dy: float): void;
    resetClip(): void;
    resetNativeClip(): void;
    excludeClip(region: Region): void;
    excludeClip(rect: CGRectangle): void;
    intersectClip(region: Region): void;
    intersectClip(rect: CGRectangle): void;
    clear(color?: CGColor): void;
    restore(gstate?: GraphicsState): void;
    save(): GraphicsState;
    drawClosedCurve(pen: Pen, points: CGPoint[]): void;
    drawClosedCurve(pen: Pen, points: CGPoint[], tension: float, fillmode: FillMode): void;
    fillClosedCurve(brush: Brush, points: CGPoint[], fillmode: FillMode, tension: float): void;
    fillClosedCurve(brush: Brush, points: CGPoint[]): void;
    drawPie(pen: Pen, x: float, y: float, width: float, height: float, startAngle: float, sweepAngle: float): void;
    drawPie(pen: Pen, rect: CGRectangle, startAngle: float, sweepAngle: float): void;
    private static radians;
    fillPie(brush: Brush, rect: CGRectangle, startAngle: float, sweepAngle: float): void;
    fillPie(brush: Brush, x: float, y: float, width: float, height: float, startAngle: float, sweepAngle: float): void;
    private polygonSetup;
    drawPolygon(pen: Pen, points: CGPoint[]): void;
    fillPolygon(brush: Brush, points: CGPoint[], fillMode: FillMode): void;
    fillPolygon(brush: Brush, points: CGPoint[]): void;
    drawRectangles(pen: Pen, rects: CGRectangle[]): void;
    fillRectangles(brush: Brush, rects: CGRectangle[]): void;
    flush(intention: FlushIntention): void;
    flush(): void;
    isVisible(x: float, y: float, width: float, height: float): boolean;
    isVisible(x: float, y: float): boolean;
    isVisible(rect: CGRectangle): boolean;
    isVisible(point: CGPoint): boolean;
    multiplyTransform(matrix: Matrix): void;
    multiplyTransform(matrix: Matrix, order: MatrixOrder): void;
    transformPoints(destSpace: CoordinateSpace, srcSpace: CoordinateSpace, pts: CGPoint[]): void;
    drawEllipticalArc(x: float, y: float, width: float, height: float, lambda1: float, lambda2: float, isPieSlice: boolean): void;
    drawEllipticalArc(arcRect: CGRectangle, lambda1: float, lambda2: float, isPieSlice: boolean): void;
    private static make_arc;
    private static make_arcs;
    measureCharacterRanges(text: string, font: Font, layoutRect: CGRectangle, stringFormat: StringFormat): Region[];
    protected abstract measureStringEx(textstring: string, font: Font): TextMetricsEx;
    MeasureString(text: string, font: Font): CGSize;
    MeasureString(text: string, font: Font, width: number): CGSize;
    MeasureString(text: string, font: Font, area: CGSize): CGSize;
    MeasureString(text: string, font: Font, point: CGPoint, stringFormat: StringFormat): CGSize;
    MeasureString(text: string, font: Font, area: CGSize, stringFormat: StringFormat): CGSize;
    MeasureString(text: string, font: Font, width: number, stringFormat: StringFormat): CGSize;
    MeasureString(text: string, font: Font, area: CGSize, format: StringFormat, charactersFitted: Out<number>, linesFilled: Out<number>): CGSize;
    drawString(s: string, font: Font, brush: Brush, x: float, y: float): void;
    drawString(s: string, font: Font, brush: Brush, x: float, y: float, format: StringFormat): void;
    drawString(s: string, font: Font, brush: Brush, point: CGPoint, format: StringFormat): void;
    drawString(s: string, font: Font, brush: Brush, x: float, y: float, format: StringFormat): void;
    drawString(s: string, font: Font, brush: Brush, layoutRectangle: CGRectangle, format: StringFormat): void;
    DrawImage(image: Image, rect: CGRectangle): void;
    DrawImage(image: Image, point: CGPoint): void;
    DrawImage(image: Image, destPoints: CGPoint[]): void;
    DrawImage(image: Image, x: int, y: int): void;
    DrawImage(image: Image, destRect: CGRectangle, srcRect: CGRectangle, srcUnit: GraphicsUnit): void;
    DrawImage(image: Image, destPoints: CGPoint[], srcRect: CGRectangle, srcUnit: GraphicsUnit): void;
    DrawImage(image: Image, destPoints: CGPoint[], srcRect: CGRectangle, srcUnit: GraphicsUnit, imageAttr: ImageAttributes): void;
    DrawImage(image: Image, x: float, y: float, width: float, height: float): void;
    drawImageBitmap(image: ImageBitmap, x: float, y: float): void;
    createRectangle(x: int, y: int, width: int, height: int): CGRectangle;
    createColor(r: byte, g: byte, b: byte): CGColor;
    createSolidBrush(r: byte, g: byte, b: byte): SolidBrush;
    createPen(r: byte, g: byte, b: byte, size?: int): Pen;
}
export declare abstract class CanvasGraphics<T extends IContext2D> extends GraphicsBase<T> {
    private m_canvasElement;
    constructor();
    constructor(handle: IntPtr);
    constructor(width: number, height: number);
    constructor(width: number, height: number, pixelSize: int);
    constructor(left: number, top: number, width: number, height: number);
    constructor(context: CanvasRenderingContext2D, flipped?: boolean);
    constructor(context: CGContext2D, flipped?: boolean);
    abstract provideRenderer2D(): T;
    abstract provideRenderer2D(context: CanvasRenderingContext2D): T;
    setSize(width: int, height: int): void;
    init(): void;
    getContext(): CanvasRenderingContext2D;
    getCanvas(): HTMLCanvasElement;
    private getCSSValue;
    measureStringEx(textstring: string, font: Font): TextMetricsEx;
    static fromCurrentContext(): Graphics;
}
export interface IDeviceContext {
    GetHdc(): IntPtr;
    ReleaseHdc(): void;
}
export declare class Graphics extends CanvasGraphics<CGContext2D> implements IDeviceContext {
    static FromImage(image: Image): Graphics;
    GetHdc(): IntPtr;
    static FromHwnd(handle: IntPtr): Graphics;
    ReleaseHdc(): void;
    init(): void;
    provideRenderer2D(): CGContext2D;
    provideRenderer2D(canvasContext: CanvasRenderingContext2D): CGContext2D;
    static fromCurrentContext(): Graphics;
}
export declare class CommandGraphics extends GraphicsBase<CGCommandContext2D> {
    constructor();
    protected measureStringEx(textstring: string, font: Font): TextMetricsEx;
    provideRenderer2D(): CGCommandContext2D;
    init(): void;
}
export declare class OffScreenGraphics extends GraphicsBase<CGContext2D> {
    private m_OffScreenCanvas;
    private m_Context;
    constructor(width: int, height: int);
    protected measureStringEx(textstring: string, font: Font): TextMetricsEx;
    provideRenderer2D(): CGContext2D;
    provideRenderer2D(canvasContext: any): CGContext2D;
    init(): void;
    TrasferToImageBitmap(): ImageBitmap;
}
