import { Font } from "./Font";
export declare class SystemFonts {
    static StaticConstructor(): void;
    static GetFontByName(systemFontName: string): Font;
    static CaptionFont: Font;
    static DefaultFont: Font;
    static DialogFont: Font;
    static IconTitleFont: Font;
    static MenuFont: Font;
    static MessageBoxFont: Font;
    static SmallCaptionFont: Font;
    static StatusFont: Font;
}
