export declare class DrawStringCache {
    constructor(name: number);
}
