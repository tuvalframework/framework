import { CGImage } from "@tuval/cg";
export declare class Icon {
    toBitmap(): CGImage;
}
