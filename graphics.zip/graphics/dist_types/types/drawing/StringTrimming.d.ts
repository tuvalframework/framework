export declare enum StringTrimming {
    None = 0,
    Character = 1,
    Word = 2,
    EllipsisCharacter = 3,
    EllipsisWord = 4,
    EllipsisPath = 5
}
