export declare class Event {
    type: string;
    target: any;
    currentTarget: any;
    eventPhase: any;
    bubbles: boolean;
    cancelable: boolean;
    timeStamp: any;
    defaultPrevented: any;
    propagationStopped: boolean;
    immediatePropagationStopped: boolean;
    private removed;
    constructor(type: any, bubbles?: boolean, cancelable?: boolean);
    /**
     * Sets {@link core.Event#defaultPrevented} to true if the event is cancelable.
     * Mirrors the DOM level 2 event standard. In general, cancelable events that have `preventDefault()` called will
     * cancel the default behaviour associated with the event.
     * @return {core.Event} this, chainable
     */
    preventDefault(): this;
    /**
     * Sets {@link core.Event#propagationStopped} to true.
     * Mirrors the DOM event standard.
     * @return {core.Event} this, chainable
     */
    stopPropagation(): this;
    /**
     * Sets {@link core.Event#propagationStopped} and {@link core.Event#immediatePropagationStopped} to true.
     * Mirrors the DOM event standard.
     * @return {core.Event} this, chainable
     */
    stopImmediatePropagation(): this;
    /**
     * Causes the active listener to be removed via removeEventListener();
     *
     * @example
     * myBtn.addEventListener("click", event => {
     *   event.remove(); // removes this listener.
     * });
     *
     * @return {core.Event} this, chainable
     */
    remove(): this;
    /**
     * Returns a clone of the Event instance.
     *
     * @return {core.Event} a clone of the Event instance.
     */
    clone(): Event;
    /**
     * Provides a return {core.Event} this, chainable shortcut method for setting a number of properties on the instance.
     *
     * @param {Object} props A generic object containing properties to copy to the instance.
     * @return {core.Event} this, chainable
     */
    set(props: any): this;
    /**
     * Returns a string representation of this object.
     *
     * @return {string} A string representation of the instance.
     */
    toString(): string;
}
