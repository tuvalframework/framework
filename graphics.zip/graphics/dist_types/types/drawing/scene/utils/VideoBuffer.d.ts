/**
 * When an HTML video seeks, including when looping, there is an indeterminate period before a new frame is available.
 * This can result in the video blinking or flashing when it is drawn to a canvas. The VideoBuffer class resolves
 * this issue by drawing each frame to an off-screen canvas and preserving the prior frame during a seek.
 *
 * @example
 * let buffer = new VideoBuffer(video);
 * let bitmap = new Bitmap(buffer);
 *
 * @param {HTMLVideoElement} video The HTML video element to buffer.
 */
export declare class VideoBuffer {
    /**
     * Used by Bitmap to determine when the video buffer is ready to be drawn. Not intended for general use.
     * @protected
     * @type {Number}
     */
    readyState: number;
    /**
     * @protected
     * @type {HTMLVideoElement}
     */
    protected _video: HTMLVideoElement;
    /**
     * @protected
     * @type {HTMLCanvasElement}
     */
    protected _canvas: HTMLCanvasElement;
    /**
     * @protected
     * @type {Number}
     * @default -1
     */
    protected _lastTime: number;
    constructor(video: HTMLVideoElement);
    /**
     * Gets an HTML canvas element showing the current video frame, or the previous frame if in a seek / loop.
     * Primarily for use by {@link easeljs.Bitmap}.
     */
    getImage(): HTMLCanvasElement;
    /**
     * @protected
     */
    protected _videoReady(): void;
}
