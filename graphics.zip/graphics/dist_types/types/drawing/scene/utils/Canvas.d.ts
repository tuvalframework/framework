export declare function createCanvas(width?: number, height?: number): any;
