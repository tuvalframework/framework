import { CGRectangle } from '@tuval/cg';
import { DisplayObject } from "./DisplayObject";
export declare class Text extends DisplayObject {
    text: string;
    font: string;
    color: string;
    textAlign: string;
    textBaseline: string;
    maxWidth: number;
    outline: number;
    lineHeight: number;
    lineWidth: number;
    private static _ctx;
    private static readonly V_OFFSETS;
    private static readonly H_OFFSETS;
    constructor(text: string, font: string, color: string);
    isVisible(): boolean;
    draw(ctx: CanvasRenderingContext2D, ignoreCache?: boolean): boolean;
    /**
     * Returns the measured, untransformed width of the text without wrapping. Use getBounds for a more robust value.
     * @return {Number} The measured, untransformed width of the text.
     */
    getMeasuredWidth(): number;
    /**
     * Returns an approximate line height of the text, ignoring the lineHeight property. This is based on the measured
     * width of a "M" character multiplied by 1.2, which provides an approximate line height for most fonts.
     * @return {Number} an approximate line height of the text, ignoring the lineHeight property. This is
     * based on the measured width of a "M" character multiplied by 1.2, which approximates em for most fonts.
     */
    getMeasuredLineHeight(): number;
    /**
     * Returns the approximate height of multi-line text by multiplying the number of lines against either the
     * `lineHeight` (if specified) or {@link easeljs.Text#getMeasuredLineHeight}. Note that
     * this operation requires the text flowing logic to run, which has an associated CPU cost.
     * @return {Number} The approximate height of the untransformed multi-line text.
     */
    getMeasuredHeight(): number;
    getBounds(): CGRectangle;
    /**
     * Returns an object with width, height, and lines properties. The width and height are the visual width and height
     * of the drawn text. The lines property contains an array of strings, one for
     * each line of text that will be drawn, accounting for line breaks and wrapping. These strings have trailing
     * whitespace removed.
     * @return {Object} An object with width, height, and lines properties.
     */
    getMetrics(): any;
    /**
     * Returns a clone of the Text instance.
     * @return {easeljs.Text} a clone of the Text instance.
     */
    clone(test?: boolean): Text;
    /**
     * Returns a string representation of this object.
     * @override
     * @return {String} a string representation of the instance.
     */
    toString(): string;
    /**
     * @param {easeljs.Text} o
     * @protected
     * @return {easeljs.Text} o
     */
    protected _cloneProps(o: Text): Text;
    /**
     * @param {CanvasRenderingContext2D} ctx
     * @return {CanvasRenderingContext2D}
     * @protected
     */
    protected _prepContext(ctx: any): any;
    /**
     * Draws multiline text.
     * @param {CanvasRenderingContext2D} ctx
     * @param {Object} o
     * @param {Array} lines
     * @return {Object}
     * @protected
     */
    protected _drawText(ctx: any, o?: any, lines?: any): any;
    /**
     * @param {CanvasRenderingContext2D} ctx
     * @param {String} text
     * @param {Number} y
     * @protected
     */
    _drawTextLine(ctx: any, text: any, y: any): void;
    /**
     * @param {String} text
     * @protected
     */
    _getMeasuredWidth(text: any): any;
}
