export declare class StageGL {
    constructor(arg1: any, arg2: any);
}
