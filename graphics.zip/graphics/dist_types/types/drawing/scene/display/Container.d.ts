import { CGRectangle } from '@tuval/cg';
import { DisplayObject } from "./DisplayObject";
import { Matrix2D } from "../geom/Matrix2D";
import { float } from "@tuval/core";
/**
 * A Container is a nestable display list that allows you to work with compound display elements. For  example you could
 * group arm, leg, torso and head {{#crossLink "Bitmap"}}{{/crossLink}} instances together into a Person Container, and
 * transform them as a group, while still being able to move the individual parts relative to each other. Children of
 * containers have their `transform` and `alpha` properties concatenated with their parent
 * Container.
 *
 * For example, a {{#crossLink "Shape"}}{{/crossLink}} with x=100 and alpha=0.5, placed in a Container with `x=50`
 * and `alpha=0.7` will be rendered to the canvas at `x=150` and `alpha=0.35`.
 * Containers have some overhead, so you generally shouldn't create a Container to hold a single child.
 *
 * @memberof Tuval
 * @extends DisplayObject
 * @example
 * const container = new Tuval.Container();
 * container.addChild(bitmapInstance, shapeInstance);
 * container.x = 100;
 */
export declare class Container extends DisplayObject {
    /**
     * The array of children in the display list. You should usually use the child management methods such as
     * {@link Container#addChild}, {@link Container#removeChild}, {@link Container#swapChildren},
     * etc, rather than accessing this directly, but it is included for advanced uses.
     * @type {Array}
     * @default []
     */
    children: Array<DisplayObject>;
    /**
     * Indicates whether the children of this container are independently enabled for mouse/pointer interaction.
     * If false, the children will be aggregated under the container - for example, a click on a child shape would
     * trigger a click event on the container.
     * @type {Boolean}
     * @default true
     */
    mouseChildren: boolean;
    /**
     * If false, the tick will not be propagated to children of this Container. This can provide some performance benefits.
     * In addition to preventing the {@link core.Ticker#event:tick} event from being dispatched, it will also prevent tick related updates
     * on some display objects (ex. Sprite & MovieClip frame advancing, DOMElement visibility handling).
     * @type {Boolean}
     * @default true
     */
    tickChildren: boolean;
    constructor();
    /**
     * Returns the number of children in the container.
     * @type {Number}
     * @readonly
     */
    get numChildren(): number;
    isVisible(): boolean;
    draw(ctx: any, ignoreCache?: boolean): boolean;
    /**
     * Adds a child to the top of the display list.
     *
     * @example
     * container.addChild(bitmapInstance);
     * // You can also add multiple children at once:
     * container.addChild(bitmapInstance, shapeInstance, textInstance);
     *
     * @param {...DisplayObject} children The display object(s) to add.
     * @return {DisplayObject} The child that was added, or the last child if multiple children were added.
     */
    addChild(...children: DisplayObject[]): DisplayObject | null;
    /**
     * Adds a child to the display list at the specified index, bumping children at equal or greater indexes up one, and
     * setting its parent to this container.
     *
     * @example
     * container.addChildAt(child1, index);
     * // You can also add multiple children, such as:
     * container.addChildAt(child1, child2, ..., index);
     * // The index must be between 0 and numChildren. For example, to add myShape under otherShape in the display list, you could use:
     * container.addChildAt(myShape, container.getChildIndex(otherShape));
     * // This would also bump otherShape's index up by one. Fails silently if the index is out of range.
     *
     * @param {...DisplayObject} children The display object(s) to add.
     * @param {Number} index The index to add the child at.
     * @return {DisplayObject} Returns the last child that was added, or the last child if multiple children were added.
     */
    addChildAt(...children: DisplayObject[]): DisplayObject;
    /**
     * Removes the specified child from the display list. Note that it is faster to use removeChildAt() if the index is
     * already known.
     *
     * @example
     * container.removeChild(child);
     * // You can also remove multiple children:
     * container.removeChild(child1, child2, ...);
     *
     * @param {...DisplayObject} children The display object(s) to remove.
     * @return {Boolean} true if the child (or children) was removed, or false if it was not in the display list.
     */
    removeChild(...children: DisplayObject[]): boolean;
    /**
     * Removes the child at the specified index from the display list, and sets its parent to null.
     *
     * @example
     * container.removeChildAt(2);
     * // You can also remove multiple children:
     * container.removeChildAt(2, 7, ...)
     *
     * @param {...Number} indexes The indexes of children to remove.
     * @return {Boolean} true if the child (or children) was removed, or false if any index was out of range.
     */
    removeChildAt(...indexes: any[]): boolean;
    /**
     * Removes all children from the display list.
     */
    removeAllChildren(): void;
    /**
     * Returns the child at the specified index.
     * @param {Number} index The index of the child to return.
     * @return {DisplayObject} The child at the specified index. Returns null if there is no child at the index.
     */
    getChildAt(index: number): DisplayObject;
    /**
     * Returns the child with the specified name.
     * @param {String} name The name of the child to return.
     * @return {DisplayObject} The child with the specified name.
     */
    getChildByName(name: string): DisplayObject;
    /**
     * Performs an array sort operation on the child list.
     *
     * @example
     * // Display children with a higher y in front.
     * container.sortChildren((obj1, obj2, options) => {
     * 	 if (obj1.y > obj2.y) { return 1; }
     *   if (obj1.y < obj2.y) { return -1; }
     *   return 0;
     * });
     *
     * @see {@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/sort}
     * @param {Function} sortFunction the function to use to sort the child list.
     */
    sortChildren(sortFunction: Function): void;
    /**
     * Returns the index of the specified child in the display list, or -1 if it is not in the display list.
     * @param {DisplayObject} child The child to return the index of.
     * @return {Number} The index of the specified child. -1 if the child is not found.
     */
    getChildIndex(child: DisplayObject): number;
    /**
     * Swaps the children at the specified indexes. Fails silently if either index is out of range.
     * @param {Number} index1
     * @param {Number} index2
     */
    swapChildrenAt(index1: number, index2: number): void;
    /**
     * Swaps the specified children's depth in the display list. Fails silently if either child is not a child of this
     * Container.
     * @param {DisplayObject} child1
     * @param {DisplayObject} child2
     */
    swapChildren(child1: DisplayObject, child2: DisplayObject): void;
    /**
     * Changes the depth of the specified child. Fails silently if the child is not a child of this container, or the index is out of range.
     * @param {DisplayObject} child
     * @param {Number} index
     */
    setChildIndex(child: DisplayObject, index: number): void;
    /**
     * Returns true if the specified display object either is this container or is a descendent (child, grandchild, etc)
     * of this container.
     * @param {DisplayObject} child The DisplayObject to be checked.
     * @return {Boolean} true if the specified display object either is this container or is a descendent.
     */
    contains(child: DisplayObject): boolean;
    /**
     * Tests whether the display object intersects the specified local point (ie. draws a pixel with alpha > 0 at the
     * specified position). This ignores the alpha, shadow and compositeOperation of the display object, and all
     * transform properties including regX/Y.
     * @param {Number} x The x position to check in the display object's local coordinates.
     * @param {Number} y The y position to check in the display object's local coordinates.
     * @return {Boolean} A Boolean indicating whether there is a visible section of a DisplayObject that overlaps the specified
     * coordinates.
     */
    hitTest(x: float, y: float): boolean;
    /**
     * Returns an array of all display objects under the specified coordinates that are in this container's display
     * list. This routine ignores any display objects with {@link DisplayObject#mouseEnabled} set to `false`.
     * The array will be sorted in order of visual depth, with the top-most display object at index 0.
     * This uses shape based hit detection, and can be an expensive operation to run, so it is best to use it carefully.
     * For example, if testing for objects under the mouse, test on tick (instead of on {@link DisplayObject#event:mousemove}),
     * and only if the mouse's position has changed.
     *
     * <ul>
     *   <li>By default (mode=0) this method evaluates all display objects.</li>
     *   <li>By setting the `mode` parameter to `1`, the {@link DisplayObject#mouseEnabled}
     *       and {@link DisplayObject#mouseChildren} properties will be respected.</li>
     *   <li>Setting the `mode` to `2` additionally excludes display objects that do not have active mouse event
     *       listeners or a {@link DisplayObject#cursor} property. That is, only objects
     *       that would normally intercept mouse interaction will be included. This can significantly improve performance
     *       in some cases by reducing the number of display objects that need to be tested.</li>
     * </ul>
     *
     * This method accounts for both {@link DisplayObject#hitArea} and {@link DisplayObject#mask}.
     *
     * @param {Number} x The x position in the container to test.
     * @param {Number} y The y position in the container to test.
     * @param {Number} [mode=0] The mode to use to determine which display objects to include. 0-all, 1-respect mouseEnabled/mouseChildren, 2-only mouse opaque objects.
     * @return {Array<DisplayObject>} An array of DisplayObjects under the specified coordinates.
     */
    getObjectsUnderPoint(x: float, y: float, mode?: number): never[];
    /**
     * Similar to {@link Container#getObjectsUnderPoint}, but returns only the top-most display
     * object. This runs significantly faster than `getObjectsUnderPoint()`, but is still potentially an expensive
     * operation.
     *
     * @param {Number} x The x position in the container to test.
     * @param {Number} y The y position in the container to test.
     * @param {Number} [mode=0] The mode to use to determine which display objects to include.  0-all, 1-respect mouseEnabled/mouseChildren, 2-only mouse opaque objects.
     * @return {DisplayObject} The top-most display object under the specified coordinates.
     */
    getObjectUnderPoint(x: float, y: float, mode?: number): any;
    getBounds(): CGRectangle;
    getTransformedBounds(): CGRectangle;
    /**
     * Returns a clone of this Container. Some properties that are specific to this instance's current context are
     * reverted to their defaults (for example `.parent`).
     * @param {Boolean} [recursive=false] If true, all of the descendants of this container will be cloned recursively. If false, the
     * properties of the container will be cloned, but the new instance will not have any children.
     * @return {Container} A clone of the current Container instance.
     */
    clone(recursive?: boolean): Container;
    _tick(evtObj: any): void;
    /**
     * Recursively clones all children of this container, and adds them to the target container.
     * @protected
     * @param {Container} o The target container.
     */
    protected _cloneChildren(o: Container): void;
    /**
     * Removes the child at the specified index from the display list, and sets its parent to null.
     * Used by `removeChildAt`, `addChild`, and `addChildAt`.
     *
     * @protected
     * @param {Number} index The index of the child to remove.
     * @param {Boolean} [silent=false] Prevents dispatch of `removed` event if true.
     * @return {Boolean} true if the child (or children) was removed, or false if any index was out of range.
     */
    protected _removeChildAt(index: number, silent?: boolean): boolean;
    /**
     * @protected
     * @param {Number} x
     * @param {Number} y
     * @param {Array} arr
     * @param {Boolean} mouse If true, it will respect mouse interaction properties like mouseEnabled, mouseChildren, and active listeners.
     * @param {Boolean} activeListener If true, there is an active mouse event listener on a parent object.
     * @param {Number} [currentDepth=0] Indicates the current depth of the search.
     * @return {DisplayObject}
     */
    protected _getObjectsUnderPoint(x: float, y: float, arr: Array<DisplayObject>, mouse: boolean, activeListener?: boolean, currentDepth?: number): any;
    /**
     * @protected
     * @param {DisplayObject} target
     * @param {Number} x
     * @param {Number} y
     * @return {Boolean} Indicates whether the x/y is within the masked region.
     */
    protected _testMask(target: any, x: number, y: number): boolean;
    /**
     * @protected
     * @param {Matrix2D} matrix
     * @param {Boolean} ignoreTransform If true, does not apply this object's transform.
     * @return {Rectangle}
     */
    protected _getBounds(matrix?: Matrix2D, ignoreTransform?: boolean): CGRectangle;
}
