import { CGRectangle } from '@tuval/cg';
import { Container } from "./Container";
import { DisplayObject } from "./DisplayObject";
import { MouseEvent } from '../events/MouseEvent';
import { float } from "@tuval/core";
/**
 * A stage is the root level {@link Container} for a display list. Each time its {@link Stage#tick}
 * method is called, it will render its display list to its target canvas.
 *
 * @memberof easeljs
 * @extends Container
 * @example
 * let stage = new Stage("canvasElementId");
 * let image = new Bitmap("imagePath.png");
 * stage.addChild(image);
 * Ticker.addEventListener("tick", event => {
 *   image.x += 10;
 * 	 stage.update();
 * });
 *
 * @param {HTMLCanvasElement | String | Object} canvas A canvas object that the Stage will render to, or the string id
 * of a canvas object in the current document.
 */
export declare class Stage extends Container {
    /**
     * Indicates whether the stage should automatically clear the canvas before each render. You can set this to `false`
     * to manually control clearing (for generative art, or when pointing multiple stages at the same canvas for
     * example).
     *
     * @example
     * let stage = new Stage("canvasId");
     * stage.autoClear = false;
     *
     * @type {Boolean}
     * @default true
     */
    autoClear: boolean;
    /**
     * The canvas the stage will render to. Multiple stages can share a single canvas, but you must disable autoClear for all but the
     * first stage that will be ticked (or they will clear each other's render).
     *
     * When changing the canvas property you must disable the events on the old canvas, and enable events on the
     * new canvas or mouse events will not work as expected.
     *
     * @example
     * stage.enableDOMEvents(false);
     * stage.canvas = anotherCanvas;
     * stage.enableDOMEvents(true);
     *
     * @type {HTMLCanvasElement | Object}
     */
    canvas: HTMLCanvasElement | any;
    /**
     * The current mouse X position on the canvas. If the mouse leaves the canvas, this will indicate the most recent
     * position over the canvas, and mouseInBounds will be set to false.
     * @type {Number}
     * @default 0
     * @readonly
     */
    mouseX: number;
    /**
     * The current mouse Y position on the canvas. If the mouse leaves the canvas, this will indicate the most recent
     * position over the canvas, and mouseInBounds will be set to false.
     * @type {Number}
     * @default 0
     * @readonly
     */
    mouseY: number;
    /**
     * Specifies the area of the stage to affect when calling update. This can be use to selectively
     * re-draw specific regions of the canvas. If null, the whole canvas area is drawn.
     * @type {Rectangle}
     */
    drawRect: CGRectangle;
    /**
     * Indicates whether display objects should be rendered on whole pixels. You can set the {@link DisplayObject.snapToPixelEnabled}
     * property of display objects to false to enable/disable this behaviour on a per instance basis.
     * @type {Boolean}
     * @default false
     */
    snapToPixelEnabled: boolean;
    /**
     * Indicates whether the mouse is currently within the bounds of the canvas.
     * @type {Boolean}
     * @default false
     */
    mouseInBounds: boolean;
    /**
     * If true, tick callbacks will be called on all display objects on the stage prior to rendering to the canvas.
     * @type {Boolean}
     * @default true
     */
    tickOnUpdate: boolean;
    /**
     * If true, mouse move events will continue to be called when the mouse leaves the target canvas.
     * See {@link Stage#mouseInBounds}, and {@link MouseEvent} x/y/rawX/rawY.
     * @type {Boolean}
     * @default false
     */
    mouseMoveOutside: boolean;
    /**
     * Prevents selection of other elements in the html page if the user clicks and drags, or double clicks on the canvas.
     * This works by calling `preventDefault()` on any mousedown events (or touch equivalent) originating on the canvas.
     * @type {Boolean}
     * @default true
     */
    preventSelection: boolean;
    /**
     * The hitArea property is not supported for Stage.
     * @property hitArea
     * @override
     * @default null
     * @private
     */
    /**
     * Holds objects with data for each active pointer id. Each object has the following properties:
     * x, y, event, target, overTarget, overX, overY, inBounds, posEvtObj (native event that last updated position)
     * @type {Object}
     * @private
     */
    protected _pointerData: any;
    /**
     * Number of active pointers.
     * @type {Number}
     * @private
     */
    protected _pointerCount: number;
    /**
     * The ID of the primary pointer.
     * @type {String}
     * @private
     */
    protected _primaryPointerID: string;
    /**
     * @protected
     * @type {Number}
     */
    protected _mouseOverIntervalID: number;
    /**
     * @protected
     * @type {Stage}
     */
    protected _nextStage: Stage;
    /**
     * @protected
     * @type {Stage}
     */
    protected _prevStage: Stage;
    protected _eventListeners: any;
    protected _mouseOverX: number;
    protected _mouseOverY: number;
    protected _mouseOverTarget: any[];
    isUpdateRequired: boolean;
    constructor(canvas: HTMLCanvasElement | String | Object);
    /**
     * Specifies a target stage that will have mouse/touch interactions relayed to it after this stage handles them.
     * This can be useful in cases where you have multiple layered canvases and want user interactions
     * events to pass through.
     *
     * MouseOver, MouseOut, RollOver, and RollOut interactions are also passed through using the mouse over settings
     * of the top-most stage, but are only processed if the target stage has mouse over interactions enabled.
     * Considerations when using roll over in relay targets:
     * <ol>
     *   <li> The top-most (first) stage must have mouse over interactions enabled (via enableMouseOver)</li>
     *   <li> All stages that wish to participate in mouse over interaction must enable them via enableMouseOver</li>
     *   <li> All relay targets will share the frequency value of the top-most stage</li>
     * </ol>
     *
     * @example <caption>Relay mouse events from topStage to bottomStage</caption>
     * topStage.nextStage = bottomStage;
     *
     * @example <caption>Disable DOM events</caption>
     * stage.enableDOMEvents(false);
     *
     * @type {Stage}
     */
    get nextStage(): Stage;
    set nextStage(stage: Stage);
    /**
     * Each time the update method is called, the stage will call {@link Stage#tick}
     * unless {@link Stage#tickOnupdate} is set to false,
     * and then render the display list to the canvas.
     *
     * @param {Object} [props] Props object to pass to `tick()`. Should usually be a {@link core.Ticker} event object, or similar object with a delta property.
     */
    update(props?: any): void;
    draw(ctx: CanvasRenderingContext2D, ignoreCache: boolean): boolean;
    /**
     * Propagates a tick event through the display list. This is automatically called by {@link Stage#update}
     * unless {@link Stage#tickOnUpdate} is set to false.
     *
     * If a props object is passed to `tick()`, then all of its properties will be copied to the event object that is
     * propagated to listeners.
     *
     * Some time-based features in EaselJS (for example {@link Sprite#framerate} require that
     * a {@link core.Ticker#event:tick} event object (or equivalent object with a delta property) be
     * passed as the `props` parameter to `tick()`.
     *
     * @example
     * Ticker.on("tick", (evt) => {
     *   // clone the event object from Ticker, and add some custom data to it:
     * 	 let data = evt.clone().set({ greeting: "hello", name: "world" });
     * 	 // pass it to stage.update():
     * 	 stage.update(data); // subsequently calls tick() with the same param
     * });
     *
     * shape.on("tick", (evt) => {
     *   console.log(evt.delta); // the delta property from the Ticker tick event object
     * 	 console.log(evt.greeting, evt.name); // custom data: "hello world"
     * });
     *
     * @emits Stage#event:tickstart
     * @emits Stage#event:tickend
     * @param {Object} [props] An object with properties that should be copied to the event object. Should usually be a Ticker event object, or similar object with a delta property.
     */
    tick(props: any): void;
    /**
     * Default event handler that calls the Stage {@link Stage#update} method when a {@link DisplayObject#event:tick}
     * event is received. This allows you to register a Stage instance as a event listener on {@link core.Ticker} directly.
     * Note that if you subscribe to ticks using this pattern, then the tick event object will be passed through to
     * display object tick handlers, instead of `delta` and `paused` parameters.
     */
    handleEvent(evt: Event): void;
    /**
     * Clears the target canvas. Useful if {@link State#autoClear} is set to `false`.
     */
    clear(): void;
    /**
     * Returns a data url that contains a Base64-encoded image of the contents of the stage. The returned data url can
     * be specified as the src value of an image element.
     *
     * @param {String} [backgroundColor] The background color to be used for the generated image. Any valid CSS color
     * value is allowed. The default value is a transparent background.
     * @param {String} [mimeType="image/png"] The MIME type of the image format to be create. If an unknown MIME type
     * is passed in, or if the browser does not support the specified MIME type, the default value will be used.
     * @param {Number} [encoderOptions=0.92] A Number between 0 and 1 indicating the image quality to use for image
     * formats that use lossy  compression such as image/jpeg and image/webp.
     * @return {String} a Base64 encoded image.
     */
    toDataURL(backgroundColor: string, mimeType?: string, encoderOptions?: float): any;
    /**
     * Enables or disables (by passing a frequency of 0) mouse over {@link DisplayObject#event:mouseover}
     * and {@link DisplayObject#event:mouseout} and roll over events {@link DisplayObject#event:rollover}
     * and {@link DisplayObject#event:rollout} for this stage's display list. These events can
     * be expensive to generate, so they are disabled by default. The frequency of the events can be controlled
     * independently of mouse move events via the optional `frequency` parameter.
     *
     * @example
     * const stage = new Stage("canvasId");
     * stage.enableMouseOver(10); // 10 updates per second
     *
     * @param {Number} [frequency=20] Optional param specifying the maximum number of times per second to broadcast
     * mouse over/out events. Set to 0 to disable mouse over events completely. Maximum is 50. A lower frequency is less
     * responsive, but uses less CPU.
     */
    enableMouseOver(frequency?: number): void;
    /**
     * Enables or disables the event listeners that stage adds to DOM elements (window, document and canvas). It is good
     * practice to disable events when disposing of a Stage instance, otherwise the stage will continue to receive
     * events from the page.
     * When changing the canvas property you must disable the events on the old canvas, and enable events on the
     * new canvas or mouse events will not work as expected.
     *
     * @example
     * stage.enableDOMEvents(false);
     * stage.canvas = anotherCanvas;
     * stage.enableDOMEvents(true);
     *
     * @param {Boolean} [enable=true] Indicates whether to enable or disable the events.
     */
    enableDOMEvents(enable?: boolean): void;
    /**
     * Stage instances cannot be cloned.
     * @throws Stage cannot be cloned
     * @override
     */
    clone(test: boolean): Stage;
    /**
     * @protected
     * @param {HTMLElement} e
     * @returns {Object}
     */
    protected _getElementRect(e: HTMLCanvasElement): {
        left: float;
        right: float;
        top: float;
        bottom: float;
    };
    /**
     * @protected
     * @param {Number} id
     * @returns {Object}
     */
    protected _getPointerData(id: any): any;
    /**
     * @protected
     * @param {MouseEvent} [e=window.event]
     */
    protected _handleMouseMove(e?: MouseEvent): void;
    onMouseMove(e: any): void;
    /**
     * @emits {@link DisplayObject#event:mouseleave}
     * @emits {@link DisplayObject#event:mouseenter}
     * @emits {@link DisplayObject#event:pressmove}
     * @emits {@link Stage#event:stagemousemove}
     * @protected
     * @param {Number} id
     * @param {MouseEvent | Event} e
     * @param {Number} pageX
     * @param {Number} pageY
     * @param {Stage} owner Indicates that the event has already been captured & handled by the indicated stage.
     */
    protected _handlePointerMove(id: number, e: MouseEvent | Event, pageX: float, pageY: float, owner?: Stage): void;
    /**
     * @protected
     * @param {Number} id
     * @param {MouseEvent | Event} e
     * @param {Number} pageX
     * @param {Number} pageY
     */
    protected _updatePointerPosition(id: number, e: MouseEvent | Event, pageX: float, pageY: float): void;
    /**
     * @protected
     * @param {MouseEvent} e
     */
    protected _handleMouseUp(e: MouseEvent): void;
    onMouseUp(e: any): void;
    /**
     * @emits {@link Stage#event:stagemouseup}
     * @emits {@link DisplayObject#event:click}
     * @emits {@link DisplayObject#event:pressup}
     * @protected
     * @param {Number} id
     * @param {MouseEvent | Event} e
     * @param {Boolean} clear
     * @param {Stage} owner Indicates that the event has already been captured & handled by the indicated stage.
     */
    protected _handlePointerUp(id: number, e: MouseEvent | Event, clear: boolean, owner?: Stage): void;
    /**
     * @protected
     * @param {MouseEvent} e
     */
    protected _handleMouseDown(e: MouseEvent): void;
    onMouseDown(e: any): void;
    /**
     * @emits {@link Stage#event:stagemousedown}
     * @emits {@link DisplayObject#event:mousedown}
     * @protected
     * @param {Number} id
     * @param {MouseEvent | Event} e
     * @param {Number} pageX
     * @param {Number} pageY
     * @param {Stage} owner Indicates that the event has already been captured & handled by the indicated stage.
     */
    protected _handlePointerDown(id: number, e: MouseEvent | Event, pageX: number, pageY: number, owner?: Stage): void;
    /**
     * @emits {@link DisplayObject#event:mouseout}
     * @emits {@link DisplayObject#event:rollout}
     * @emits {@link DisplayObject#event:rollover}
     * @emits {@link DisplayObject#event:mouseover}
     * @param {Boolean} clear If true, clears the mouseover / rollover (ie. no target)
     * @param {Stage} owner Indicates that the event has already been captured & handled by the indicated stage.
     * @param {Stage} eventTarget The stage that the cursor is actively over.
     * @protected
     */
    protected _testMouseOver(clear?: boolean, owner?: Stage, eventTarget?: Stage): void;
    /**
     * @emits {@link DisplayObject#event:dblclick}
     * @protected
     * @param {MouseEvent} e
     * @param {Stage} owner Indicates that the event has already been captured & handled by the indicated stage.
     */
    protected _handleDoubleClick(e: MouseEvent, owner?: Stage): void;
    onDbClick(e: any, owner?: Stage): void;
    /**
     * @protected
     * @param {DisplayObject} target
     * @param {String} type
     * @param {Boolean} bubbles
     * @param {Number} pointerId
     * @param {Object} o
     * @param {MouseEvent} [nativeEvent]
     * @param {DisplayObject} [relatedTarget]
     */
    protected _dispatchMouseEvent(target: DisplayObject, type: string, bubbles: boolean, pointerId: number, o: any, nativeEvent: MouseEvent, relatedTarget?: DisplayObject): void;
}
/**
 * Dispatched when the user moves the mouse over the canvas.
 * @see {@link MouseEvent}
 * @event Stage#stagemousemove
 * @since 0.6.0
 */
/**
 * Dispatched when the user presses their left mouse button on the canvas.
 * You can use {@link Stage#mouseInBounds} to check whether the mouse is currently within the stage bounds.
 * @see {@link MouseEvent}
 * @event Stage#stagemousedown
 * @since 0.6.0
 */
/**
 * Dispatched when the user the user presses somewhere on the stage, then releases the mouse button anywhere that the page can detect it (this varies slightly between browsers).
 * You can use {@link Stage#mouseInBounds} to check whether the mouse is currently within the stage bounds.
 * @see {@link MouseEvent}
 * @event Stage#stagemouseup
 * @since 0.6.0
 */
/**
 * Dispatched when the mouse moves from within the canvas area (mouseInBounds === true) to outside it (mouseInBounds === false).
 * This is currently only dispatched for mouse input (not touch).
 * @see {@link MouseEvent}
 * @event Stage#mouseleave
 * @since 0.7.0
 */
/**
 * Dispatched when the mouse moves into the canvas area (mouseInBounds === false) from outside it (mouseInBounds === true).
 * This is currently only dispatched for mouse input (not touch).
 * @see {@link MouseEvent}
 * @event Stage#mouseenter
 * @since 0.7.0
 */
/**
 * Dispatched each update immediately before the tick event is propagated through the display list.
 * You can call preventDefault on the event object to cancel propagating the tick event.
 * @event Stage#tickstart
 * @since 0.7.0
 */
/**
 * Dispatched each update immediately after the tick event is propagated through the display list. Does not fire if
 * tickOnUpdate is false. Precedes the "drawstart" event.
 * @event Stage#tickend
 * @since 0.7.0
 */
/**
 * Dispatched each update immediately before the canvas is cleared and the display list is drawn to it.
 * You can call preventDefault on the event object to cancel the draw.
 * @event Stage#drawstart
 * @since 0.7.0
 */
/**
 * Dispatched each update immediately after the display list is drawn to the canvas and the canvas context is restored.
 * @event Stage#drawend
 * @since 0.7.0
 */ 
