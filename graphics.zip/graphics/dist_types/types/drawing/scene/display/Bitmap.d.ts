import { CGRectangle } from '@tuval/cg';
import { DisplayObject } from "./DisplayObject";
/**
 * A Bitmap represents an Image, Canvas, or Video in the display list. A Bitmap can be instantiated using an existing
 * HTML element, or a string.
 *
 * <strong>Notes:</strong>
 * <ol>
 * 	<li>When using a video source that may loop or seek, use a {@link VideoBuffer} object to
 * 	 prevent blinking / flashing.
 * 	<li>When a string path or image tag that is not yet loaded is used, the stage may need to be redrawn before it
 * 	 will be displayed.</li>
 * 	<li>Bitmaps with an SVG source currently will not respect an alpha value other than 0 or 1. To get around this,
 * 	the Bitmap can be cached.</li>
 * 	<li>Bitmaps with an SVG source will taint the canvas with cross-origin data, which prevents interactivity. This
 * 	happens in all browsers except recent Firefox builds.</li>
 * 	<li>Images loaded cross-origin will throw cross-origin security errors when interacted with using a mouse, using
 * 	methods such as `getObjectUnderPoint`, or using filters, or caching. You can get around this by setting
 * 	`crossOrigin` flags on your images before passing them to EaselJS, eg: `img.crossOrigin="Anonymous";`</li>
 * </ol>
 *
 * @memberof easeljs
 * @extends DisplayObject
 * @example
 * const bitmap = new Bitmap("./imagePath.jpg");
 */
export declare class SceneBitmap extends DisplayObject {
    /**
     * The source image to display. This can be a CanvasImageSource
     * (image, video, canvas), an object with a `getImage` method that returns a CanvasImageSource, or a string URL to an image.
     * If the latter, a new Image instance with the URL as its src will be used.
     * @property image
     * @type {CanvasImageSource|Object}
     */
    image: HTMLImageElement;
    /**
     * Specifies an area of the source image to draw. If omitted, the whole image will be drawn.
     * Notes:
     * <ul>
     *     <li>that video sources must have a width / height set to work correctly with `sourceRect`</li>
     *     <li>Cached objects will ignore the `sourceRect` property</li>
     * </ul>
     * @type {RectangleF}
     * @default null
     */
    sourceRect: CGRectangle;
    /**
    * Set as compatible with WebGL.
    * @protected
    * @type {Number}
    */
    _webGLRenderStyle: number;
    /**
     * @param {CanvasImageSource|String|Object} imageOrUri The source image to display. This can be a CanvasImageSource
     * (image, video, canvas), an object with a `getImage` method that returns a CanvasImageSource, or a string URL to an image.
     * If the latter, a new Image instance with the URL as its src will be used.
     */
    constructor(imageOrUri: CanvasImageSource | String | Object);
    isVisible(): boolean;
    draw(ctx: any, ignoreCache?: boolean): boolean;
    getBounds(): CGRectangle;
    /**
     * Returns a clone of the Bitmap instance.
     * @param {Boolean} [node=false] Whether the underlying dom element should be cloned as well.
     * @return {Bitmap} a clone of the Bitmap instance.
     */
    clone(node?: boolean): SceneBitmap;
}
