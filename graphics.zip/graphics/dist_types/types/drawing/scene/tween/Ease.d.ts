export declare class Ease {
    static linear(t: any): any;
    /**
     * Mimics the simple -100 to 100 easing in Flash Pro.
     * @param {Number} amount A value from -1 (ease in) to 1 (ease out) indicating the strength and direction of the ease.
     * @return {Function}
     */
    static get(amount: any): (t: any) => any;
    /**
     * Configurable exponential ease.
     * @param {Number} pow The exponent to use (ex. 3 would return a cubic ease).
     * @return {Function}
     */
    static getPowIn(pow: any): (t: any) => number;
    /**
     * Configurable exponential ease.
     * @param {Number} pow The exponent to use (ex. 3 would return a cubic ease).
     * @return {Function}
     */
    static getPowOut(pow: any): (t: any) => number;
    /**
     * Configurable exponential ease.
     * @param {Number} pow The exponent to use (ex. 3 would return a cubic ease).
     * @return {Function}
     */
    static getPowInOut(pow: any): (t: any) => number;
    /**
     * @param {Number} t
     * @return {Number}
     */
    static sineIn(t: any): number;
    /**
     * @param {Number} t
     * @return {Number}
     */
    static sineOut(t: any): number;
    /**
     * @param {Number} t
     * @return {Number}
     */
    static sineInOut(t: any): number;
    /**
     * Configurable "back in" ease.
     * @param {Number} amount The strength of the ease.
     * @return {Function}
     */
    static getBackIn(amount: any): (t: any) => number;
    /**
     * Configurable "back out" ease.
     * @param {Number} amount The strength of the ease.
     * @return {Function}
     */
    static getBackOut(amount: any): (t: any) => number;
    /**
     * Configurable "back in out" ease.
     * @param {Number} amount The strength of the ease.
     * @return {Function}
     */
    static getBackInOut(amount: any): (t: any) => number;
    /**
     * @param {Number} t
     * @return {Number}
     */
    static circIn(t: any): number;
    /**
     * @param {Number} t
     * @return {Number}
     */
    static circOut(t: any): number;
    /**
     * @param {Number} t
     * @return {Number}
     */
    static circInOut(t: any): number;
    /**
     * @param {Number} t
     * @return {Number}
     */
    static bounceIn(t: any): number;
    /**
     * @param {Number} t
     * @return {Number}
     */
    static bounceOut(t: any): number;
    /**
     * @param {Number} t
     * @return {Number}
     */
    static bounceInOut(t: any): number;
    /**
     * Configurable elastic ease.
     * @param {Number} amplitude
     * @param {Number} period
     * @return {Function}
     */
    static getElasticIn(amplitude: any, period: any): (t: any) => any;
    /**
     * Configurable elastic ease.
     * @param {Number} amplitude
     * @param {Number} period
     * @return {Function}
     */
    static getElasticOut(amplitude: any, period: any): (t: any) => any;
    /**
     * Configurable elastic ease.
     * @param {Number} amplitude
     * @param {Number} period
     * @return {Function}
     */
    static getElasticInOut(amplitude: any, period: any): (t: any) => number;
    /**
     * Identical to linear.
     * @param {Number} t
     * @return {Number}
     */
    static none: typeof Ease.linear;
    /**
     * @param {Number} t
     * @return {Number}
     */
    static quadIn: (t: any) => number;
    /**
     * @param {Number} t
     * @return {Number}
     */
    static quadOut: (t: any) => number;
    /**
     * @param {Number} t
     * @return {Number}
     */
    static quadInOut: (t: any) => number;
    /**
     * @param {Number} t
     * @return {Number}
     */
    static cubicIn: (t: any) => number;
    /**
     * @param {Number} t
     * @return {Number}
     */
    static cubicOut: (t: any) => number;
    /**
     * @param {Number} t
     * @return {Number}
     */
    static cubicInOut: (t: any) => number;
    /**
     * @param {Number} t
     * @return {Number}
     */
    static quartIn: (t: any) => number;
    /**
     * @param {Number} t
     * @return {Number}
     */
    static quartOut: (t: any) => number;
    /**
     * @param {Number} t
     * @return {Number}
     */
    static quartInOut: (t: any) => number;
    /**
     * @param {Number} t
     * @return {Number}
     */
    static quintIn: (t: any) => number;
    /**
     * @param {Number} t
     * @return {Number}
     */
    static quintOut: (t: any) => number;
    /**
     * @param {Number} t
     * @return {Number}
     */
    static quintInOut: (t: any) => number;
    /**
     * @param {Number} t
     * @return {Number}
     */
    static backIn: (t: any) => number;
    /**
     * @param {Number} t
     * @return {Number}
     */
    static backOut: (t: any) => number;
    /**
     * @param {Number} t
     * @return {Number}
     */
    static backInOut: (t: any) => number;
    /**
     * @param {Number} t
     * @return {Number}
     */
    static elasticIn: (t: any) => any;
    /**
     * @param {Number} t
     * @return {Number}
     */
    static elasticOut: (t: any) => any;
    /**
     * @param {Number} t
     * @return {Number}
     */
    static elasticInOut: (t: any) => number;
}
