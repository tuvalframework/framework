import { Ticker } from "@tuval/core";
import { AbstractTween } from "./AbstractTween";
import { Ease } from "./Ease";
export declare class Tween extends AbstractTween {
    pluginData: any;
    target: any;
    passive: boolean;
    _stepHead: TweenStep;
    _stepTail: TweenStep;
    _stepPosition: number;
    _actionHead: TweenAction;
    _actionTail: TweenAction;
    duration: number;
    position: number;
    private _plugins;
    private _pluginIds;
    private _injected;
    static IGNORE: any;
    static _tweens: Tween[];
    static _tweenHead: any;
    static _inTick: number;
    static _tweenTail: any;
    static _ticker: Ticker;
    static _plugins: any[];
    static _inited: boolean;
    constructor(target: any, props: any);
    /**
     * Returns a new tween instance. This is functionally identical to using `new Tween(...)`, but may look cleaner
     * with the chained syntax of TweenJS.
     *
     * @static
     * @example
     * let tween = Tween.get(target).to({ x: 100 }, 500);
     * // equivalent to:
     * let tween = new Tween(target).to({ x: 100 }, 500);
     *
     * @param {Object} target The target object that will have its properties tweened.
     * @param {Object} [props] The configuration properties to apply to this instance (ex. `{loop:-1, paused:true}`).
     * @param {Boolean} [props.useTicks]
     * @param {Boolean} [props.ignoreGlobalPause]
     * @param {Number|Boolean} [props.loop]
     * @param {Boolean} [props.reversed]
     * @param {Boolean} [props.bounce]
     * @param {Number} [props.timeScale]
     * @param {Object} [props.pluginData]
     * @param {Boolean} [props.paused]
     * @param {*} [props.position] indicates the initial position for this tween
     * @param {*} [props.onChange] adds the specified function as a listener to the `change` event
     * @param {*} [props.onComplete] adds the specified function as a listener to the `complete` event
     * @param {*} [props.override] if true, removes all existing tweens for the target
     * @return {Tween} A reference to the created tween.
     */
    static get(target: any, props?: any): Tween;
    /**
     * Advances all tweens. This typically uses the {{#crossLink "Ticker"}}{{/crossLink}} class, but you can call it
     * manually if you prefer to use your own "heartbeat" implementation.
     *
     * @static
     *
     * @param {Number} delta The change in time in milliseconds since the last tick. Required unless all tweens have
     * `useTicks` set to true.
     * @param {Boolean} paused Indicates whether a global pause is in effect. Tweens with {@link tweenjs.Tween#ignoreGlobalPause}
     * will ignore this, but all others will pause if this is `true`.
     */
    static tick(delta: any, paused: any): void;
    /**
     * Handle events that result from Tween being used as an event handler. This is included to allow Tween to handle
     * {@link tweenjs.Ticker#event:tick} events from the {@link tweenjs.Ticker}.
     * No other events are handled in Tween.
     *
     * @static
     * @since 0.4.2
     *
     * @param {Object} event An event object passed in by the {@link core.EventDispatcher}. Will
     * usually be of type "tick".
     */
    static handleEvent(event: any): void;
    /**
     * Removes all existing tweens for a target. This is called automatically by new tweens if the `override`
     * property is `true`.
     *
     * @static
     *
     * @param {Object} target The target object to remove existing tweens from.=
     */
    static removeTweens(target: any): void;
    /**
     * Stop and remove all existing tweens.
     *
     * @static
     * @since 0.4.1
     */
    static removeAllTweens(): void;
    /**
     * Indicates whether there are any active tweens on the target object (if specified) or in general.
     *
     * @static
     *
     * @param {Object} [target] The target to check for active tweens. If not specified, the return value will indicate
     * if there are any active tweens on any target.
     * @return {Boolean} Indicates if there are active tweens.
     */
    static hasActiveTweens(target: any): boolean;
    /**
     * Installs a plugin, which can modify how certain properties are handled when tweened. See the {{#crossLink "SamplePlugin"}}{{/crossLink}}
     * for an example of how to write TweenJS plugins. Plugins should generally be installed via their own `install` method, in order to provide
     * the plugin with an opportunity to configure itself.
     *
     * @static
     *
     * @param {Object} plugin The plugin to install
     * @param {Object} props The props to pass to the plugin
     */
    static installPlugin(plugin: any, props: any): void;
    /**
     * Registers or unregisters a tween with the ticking system.
     *
     * @private
     * @static
     *
     * @param {Tween} tween The tween instance to register or unregister.
     * @param {Boolean} paused If `false`, the tween is registered. If `true` the tween is unregistered.
     */
    static _register(tween: any, paused: any): void;
    /**
     * @param {tweenjs.Tween} tween
     */
    static _delist(tween: any): void;
    /**
     * Adds a wait (essentially an empty tween).
     *
     * @example
     * // This tween will wait 1s before alpha is faded to 0.
     * Tween.get(target)
     *   .wait(1000)
     *   .to({ alpha: 0 }, 1000);
     *
     * @param {Number} duration The duration of the wait in milliseconds (or in ticks if `useTicks` is true).
     * @param {Boolean} [passive=false] Tween properties will not be updated during a passive wait. This
     * is mostly useful for use with {@link tweenjs.Timeline} instances that contain multiple tweens
     * affecting the same target at different times.
     * @chainable
     */
    wait(duration: any, passive?: boolean): this;
    /**
     * Adds a tween from the current values to the specified properties. Set duration to 0 to jump to these value.
     * Numeric properties will be tweened from their current value in the tween to the target value. Non-numeric
     * properties will be set at the end of the specified duration.
     *
     * @example
     * Tween.get(target)
     *   .to({ alpha: 0, visible: false }, 1000);
     *
     * @param {Object} props An object specifying property target values for this tween (Ex. `{x:300}` would tween the x
     * property of the target to 300).
     * @param {Number} [duration=0] The duration of the tween in milliseconds (or in ticks if `useTicks` is true).
     * @param {Function} [ease=Ease.linear] The easing function to use for this tween. See the {@link tweenjs.Ease}
     * class for a list of built-in ease functions.
     * @chainable
     */
    to(props: any, duration?: number, ease?: typeof Ease.linear): this;
    /**
     * Adds a label that can be used with {@link tweenjs.Tween#gotoAndPlay}/{@link tweenjs.Tween#gotoAndStop}
     * at the current point in the tween.
     *
     * @example
     * let tween = Tween.get(foo)
     *   .to({ x: 100 }, 1000)
     *   .label("myLabel")
     *   .to({ x: 200 }, 1000);
     * // ...
     * tween.gotoAndPlay("myLabel"); // would play from 1000ms in.
     *
     * @param {String} label The label name.
     * @chainable
     */
    label(name: any): this;
    /**
     * Adds an action to call the specified function.
     *
     * @example
     * // would call myFunction() after 1 second.
     * Tween.get()
     *   .wait(1000)
     *   .call(myFunction);
     *
     * @param {Function} callback The function to call.
     * @param {Array} [params]. The parameters to call the function with. If this is omitted, then the function
     * will be called with a single param pointing to this tween.
     * @param {Object} [scope]. The scope to call the function in. If omitted, it will be called in the target's scope.
     * @chainable
     */
    call(callback: any, params?: any, scope?: any): this;
    /**
     * Adds an action to set the specified props on the specified target. If `target` is null, it will use this tween's
     * target. Note that for properties on the target object, you should consider using a zero duration {@link tweenjs.Tween#to}
     * operation instead so the values are registered as tweened props.
     *
     * @example
     * tween.wait(1000)
     *   .set({ visible: false }, foo);
     *
     * @param {Object} props The properties to set (ex. `{ visible: false }`).
     * @param {Object} [target] The target to set the properties on. If omitted, they will be set on the tween's target.
     * @chainable
     */
    set(props: any, target: any): this;
    /**
     * Adds an action to play (unpause) the specified tween. This enables you to sequence multiple tweens.
     *
     * @example
     * tween.to({ x: 100 }, 500)
     *   .play(otherTween);
     *
     * @param {Tween} [tween] The tween to play. Defaults to this tween.
     * @chainable
     */
    play(tween: any): this;
    /**
     * Adds an action to pause the specified tween.
     * At 60fps the tween will advance by ~16ms per tick, if the tween above was at 999ms prior to the current tick, it
   * will advance to 1015ms (15ms into the second "step") and then pause.
     *
     * @example
     * tween.pause(otherTween)
     *   .to({ alpha: 1 }, 1000)
     *   .play(otherTween);
     *
     * // Note that this executes at the end of a tween update,
     * // so the tween may advance beyond the time the pause action was inserted at.
   *
   * tween.to({ foo: 0 }, 1000)
   *   .pause()
   *   .to({ foo: 1 }, 1000);
     *
     * @param {Tween} [tween] The tween to pause. Defaults to this tween.
     * @chainable
     */
    pause(tween: any): this;
    /**
     * @throws Tween cannot be cloned.
     */
    clone(): void;
    /**
     * @private
     * @param {Object} plugin
     */
    _addPlugin(plugin: any): void;
    /**
     * @private
     * @param {} jump
     * @param {Boolean} end
   */
    _updatePosition(jump: any, end: any): void;
    /**
     * @private
     * @param {Object} step
     * @param {Number} ratio
     * @param {Boolean} end Indicates to plugins that the full tween has ended.
     */
    _updateTargetProps(step: any, ratio: any, end: any): void;
    /**
     * @private
     * @param {Number} startPos
     * @param {Number} endPos
     * @param {Boolean} includeStart
     */
    _runActionsRange(startPos: any, endPos: any, jump: any, includeStart: any): boolean;
    /**
     * @private
     * @param {Object} props
     */
    _appendProps(props: any, step: any, stepPlugins?: any): void;
    /**
     * Used by plugins to inject properties onto the current step. Called from within `Plugin.step` calls.
     * For example, a plugin dealing with color, could read a hex color, and inject red, green, and blue props into the tween.
     * See the SamplePlugin for more info.
     * @see tweenjs.SamplePlugin
     * @private
     * @param {String} name
     * @param {Object} value
     */
    _injectProp(name: any, value: any): void;
    /**
     * @private
     * @param {Number} duration
     * @param {Object} props
     * @param {Function} ease
     * @param {Boolean} [passive=false]
     */
    _addStep(duration: any, props: any, ease: any, passive?: boolean): TweenStep;
    /**
     * @private
     * @param {Object} scope
     * @param {Function} funct
     * @param {Array} params
     */
    _addAction(scope: any, funct: any, params: any): this;
    /**
     * @private
     * @param {Object} props
     */
    _set(props: any): void;
    /**
     * @private
     * @param {Object} props
     */
    _cloneProps(props: any): {};
}
/**
 * @private
 * @param {*} prev
 * @param {*} t
 * @param {*} d
 * @param {*} props
 * @param {*} ease
 * @param {*} passive
 */
declare class TweenStep {
    next: any;
    prev: any;
    t: any;
    d: any;
    props: any;
    ease: any;
    passive: any;
    index: number;
    constructor(prev: any, t: any, d: any, props: any, ease: any, passive: any);
}
/**
 * @private
 * @param {*} prev
 * @param {*} t
 * @param {*} scope
 * @param {*} funct
 * @param {*} params
 */
declare class TweenAction {
    next: any;
    d: any;
    prev: any;
    t: any;
    scope: any;
    funct: any;
    params: any;
    constructor(prev: any, t: any, scope: any, funct: any, params: any);
}
export {};
