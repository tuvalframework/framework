import { EventDispatcher } from "@tuval/core";
export declare class AbstractTween extends EventDispatcher {
    ignoreGlobalPause: boolean;
    loop: number;
    useTicks: boolean;
    reversed: boolean;
    bounce: boolean;
    timeScale: number;
    duration: number;
    position: number;
    rawPosition: number;
    private _paused;
    private _next;
    private _prev;
    private _parent;
    private _labels;
    private _labelList;
    private _status;
    private _lastTick;
    protected _actionHead: any;
    private tweens;
    constructor(props: any);
    /**
     * Returns a list of the labels defined on this tween sorted by position.
     * @type {Object[]}
     */
    get labels(): any;
    set labels(labels: any);
    /**
     * Returns the name of the label on or immediately before the current position. For example, given a tween with
     * two labels, "first" on frame index 4, and "second" on frame 8, currentLabel would return:
     * <ul>
     *   <li>null if the current position is 2.</li>
     *   <li>"first" if the current position is 4.</li>
     *   <li>"first" if the current position is 7.</li>
     *   <li>"second" if the current position is 15.</li>
     * </ul>
     * @type {String}
     * @readonly
     */
    get currentLabel(): any;
    /**
     * Pauses or unpauses the tween. A paused tween is removed from the global registry and is eligible for garbage collection
     * if no other references to it exist.
     * @type {Boolean}
       */
    get paused(): boolean;
    set paused(paused: boolean);
    /**
     * Advances the tween by a specified amount.	 *
     * @param {Number} delta The amount to advance in milliseconds (or ticks if useTicks is true). Negative values are supported.
     * @param {Boolean} [ignoreActions=false] If true, actions will not be executed due to this change in position.
     */
    advance(delta: any, ignoreActions?: boolean): void;
    /**
     * Advances the tween to a specified position.
     *
     * @emits tweenjs.AbstractTween#event:change
     * @emits tweenjs.AbstractTween#event:complete
     *
     * @param {Number} rawPosition The raw position to seek to in milliseconds (or ticks if useTicks is true).
     * @param {Boolean} [ignoreActions=false] If true, do not run any actions that would be triggered by this operation.
     * @param {Boolean} [jump=false] If true, only actions at the new position will be run. If false, actions between the old and new position are run.
     * @param {Function} [callback] Primarily for use with MovieClip, this callback is called after properties are updated, but before actions are run.
     */
    setPosition(rawPosition: any, ignoreActions?: boolean, jump?: boolean, callback?: any): boolean | undefined;
    /**
     * Calculates a normalized position based on a raw position.
     *
     * @example
     * // given a tween with a duration of 3000ms set to loop:
     * console.log(myTween.calculatePosition(3700); // 700
     *
     * @param {Number} rawPosition A raw position.
     */
    calculatePosition(rawPosition: any): number;
    /**
     * Adds a label that can be used with {@link tweenjs.Timeline#gotoAndPlay}/{@link tweenjs.Timeline#gotoAndStop}.
     *
     * @param {String} label The label name.
     * @param {Number} position The position this label represents.
     */
    addLabel(label: any, position: any): void;
    /**
     * Unpauses this timeline and jumps to the specified position or label.
     *
     * @param {String|Number} positionOrLabel The position in milliseconds (or ticks if `useTicks` is `true`)
     * or label to jump to.
     */
    gotoAndPlay(positionOrLabel: any): void;
    /**
     * Pauses this timeline and jumps to the specified position or label.
     *
     * @param {String|Number} positionOrLabel The position in milliseconds (or ticks if `useTicks` is `true`) or label
     * to jump to.
     */
    gotoAndStop(positionOrLabel: any): void;
    /**
     * If a numeric position is passed, it is returned unchanged. If a string is passed, the position of the
     * corresponding frame label will be returned, or `null` if a matching label is not defined.
     *
     * @param {String|Number} positionOrLabel A numeric position value or label String.
     */
    resolve(positionOrLabel: any): any;
    /**
     * Returns a string representation of this object.
     *
     * @return {String} a string representation of the instance.
     */
    toString(): string;
    /**
     * @throws AbstractTween cannot be cloned.
     */
    clone(): void;
    /**
     * Shared logic that executes at the end of the subclass constructor.
     *
     * @private
     *
     * @param {Object} [props]
     */
    _init(props: any): void;
    /**
     * @private
     * @param {String|Number} positionOrLabel
     */
    _goto(positionOrLabel: any): void;
    /**
   * Runs actions between startPos & endPos. Separated to support action deferral.
   *
     * @private
     *
     * @param {Number} startRawPos
     * @param {Number} endRawPos
     * @param {Boolean} jump
     * @param {Boolean} includeStart
     */
    _runActions(startRawPos: any, endRawPos: any, jump: any, includeStart: any): boolean | undefined;
    /**
     * @private
     * @abstract
     * @throws Must be overridden by a subclass.
       */
    _runActionsRange(startPos: any, endPos: any, jump: any, includeStart: any): boolean;
    /**
       * @private
     * @abstract
     * @throws Must be overridden by a subclass.
       */
    _updatePosition(jump: any, end: any): void;
}
/**
 * Dispatched whenever the tween's position changes. It occurs after all tweened properties are updated and actions
 * are executed.
 * @event tweenjs.AbstractTween#change
 */
/**
 * Dispatched when the tween reaches its end and has paused itself. This does not fire until all loops are complete;
 * tweens that loop continuously will never fire a complete event.
 * @event tweenjs.AbstractTween#complete
 */ 
