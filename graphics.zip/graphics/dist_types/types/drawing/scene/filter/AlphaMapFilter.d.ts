import { Filter } from "./Filter";
/**
 * Applies a greyscale alpha map image (or canvas) to the target, such that the alpha channel of the result will
 * be copied from the red channel of the map, and the RGB channels will be copied from the target.
 *
 * Generally, it is recommended that you use {@link easeljs.AlphaMaskFilter}, because it has much better performance.
 *
 * @memberof easeljs
 * @extends easeljs.Filter
 * @example *
 * let box = new Shape();
 * box.graphics.beginLinearGradientFill(["#ff0000", "#0000ff"], [0, 1], 0, 0, 0, 100)
 * box.graphics.drawRect(0, 0, 100, 100);
 * box.cache(0, 0, 100, 100);
 * let bmp = new Bitmap("path/to/image.jpg");
 * bmp.filters = [ new AlphaMapFilter(box.cacheCanvas) ];
 * bmp.cache(0, 0, 100, 100);
 *
 * @param {HTMLImageElement|HTMLCanvasElement|WebGLTexture} alphaMap The greyscale image (or canvas) to use as the alpha value for the
 * result. This should be exactly the same dimensions as the target.
 */
export declare class AlphaMapFilter extends Filter {
    /**
         * The greyscale image (or canvas) to use as the alpha value for the result. This should be exactly the same
         * dimensions as the target.
         * @type {HTMLImageElement|HTMLCanvasElement|WebGLTexture}
         */
    private alphaMap;
    /**
     * @protected
     * @type {HTMLImageElement|HTMLCanvasElement}
     * @default null
     */
    private _map;
    /**
         * @protected
         * @type {CanvasRenderingContext2D}
         * @default null
         */
    private _mapCtx;
    /**
     * @protected
     * @type {WebGLTexture}
     * @default null
     */
    private _mapTexture;
    protected FRAG_SHADER_BODY: string;
    constructor(alphaMap: any);
    /**
     * @todo docs
     * @param {*} gl
     * @param {*} stage
     * @param {*} shaderProgram
     */
    shaderParamSetup(gl: any, stage: any, shaderProgram: any): void;
    /**
     * @return {easeljs.AlphaMapFilter}
     */
    clone(): Filter;
    protected _applyFilter(imageData: ImageData): boolean;
    /**
     * @protected
     */
    _prepAlphaMap(): boolean;
}
