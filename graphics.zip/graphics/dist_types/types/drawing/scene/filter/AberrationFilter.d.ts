import { Filter } from "./Filter";
import { float } from "@tuval/core";
/**
 * Separates and pushes each of the colour channels apart. I.E. shift the red channel slightly left.
 * Allows specifying the direction and the ammount it affects each channel. Great for computer glitches and VCR like
 * effects.
 *
 * @memberof easeljs
 * @extends easeljs.Filter
 */
export declare class AberrationFilter extends Filter {
    private xDir;
    private yDir;
    private redMultiplier;
    private greenMultiplier;
    private blueMultiplier;
    private originalMix;
    private _alphaMax;
    /**
     * @param {Number} [xDir=0] Movement in x at a multiplier of 1, specified in pixels.
     * @param {Number} [yDir=0] Movement in y at a multiplier of 1, specified in pixels.
     * @param {Number} [redMultiplier=0] Multiplier for the movement of the Red channel. Negative values allowed.
     * @param {Number} [greenMultiplier=0] Multiplier for the movement of the Green channel. Negative values allowed.
     * @param {Number} [blueMultiplier=0] Multiplier for the movement of the Blue channel. Negative values allowed.
     * @param {Number} [originalMix=0] Amount of original image to keep, 0-1.
     * @param {Boolean} [alphaMax=false] Calculate combined alpha using maximum alpha available. Creates a stronger image.
     */
    constructor(xDir?: float, yDir?: float, redMultiplier?: float, greenMultiplier?: float, blueMultiplier?: float, originalMix?: float, alphaMax?: boolean);
    /**
     * @param {WebGLRenderingContext} gl
     * @param {easeljs.StageGL} stage
     * @param {String} shaderProgram
     */
    shaderParamSetup(gl: any, stage: any, shaderProgram: any): void;
    /**
     * @param {Object} imageData
     */
    _applyFilter(imageData: any): boolean;
}
