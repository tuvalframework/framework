import { Filter } from "./Filter";
/**
 * Applies the alpha from the mask image (or canvas) to the target, such that the alpha channel of the result will
 * be derived from the mask, and the RGB channels will be copied from the target. This can be used, for example, to
 * apply an alpha mask to a display object. This can also be used to combine a JPG compressed RGB image with a PNG32
 * alpha mask, which can result in a much smaller file size than a single PNG32 containing ARGB.
 *
 * <b>IMPORTANT NOTE: This filter currently does not support the targetCtx, or targetX/Y parameters correctly.</b>
 *
 * @memberof easeljs
 * @extends easeljs.Filter
 * @example
 * var box = new Shape();
 * box.graphics.beginLinearGradientFill(["#000000", "rgba(0, 0, 0, 0)"], [0, 1], 0, 0, 100, 100)
 * box.graphics.drawRect(0, 0, 100, 100);
 * box.cache(0, 0, 100, 100);
 * var bmp = new Bitmap("path/to/image.jpg");
 * bmp.filters = [ new AlphaMaskFilter(box.cacheCanvas) ];
 * bmp.cache(0, 0, 100, 100);
 *
 * @param {HTMLImageElement|HTMLCanvasElement|WebGLTexture} mask
 */
export declare class AlphaMaskFilter extends Filter {
    /**
         * The image (or canvas) to use as the mask.
         * @type {HTMLImageElement | HTMLCanvasElement}
         */
    private mask;
    protected FRAG_SHADER_BODY: string;
    private _mapTexture;
    constructor(mask: any);
    /**
     * Applies the filter to the specified context.
     *
     * <strong>IMPORTANT NOTE: This filter currently does not support the targetCtx, or targetX/Y parameters correctly.</strong>
     * @param {CanvasRenderingContext2D} ctx The 2D context to use as the source.
     * @param {Number} x The x position to use for the source rect.
     * @param {Number} y The y position to use for the source rect.
     * @param {Number} width The width to use for the source rect.
     * @param {Number} height The height to use for the source rect.
     * @param {CanvasRenderingContext2D} [targetCtx] The 2D context to draw the result to. Defaults to the context passed to ctx.
     * @return {Boolean} If the filter was applied successfully.
     */
    applyFilter(ctx: any, x: any, y: any, width: any, height: any, targetCtx: any): boolean;
    /**
     * @return {easeljs.AlphaMaskFilter}
     */
    clone(): Filter;
    /**
     * @todo docs
     * @param {*} gl
     * @param {*} stage
     * @param {*} shaderProgram
     */
    shaderParamSetup(gl: any, stage: any, shaderProgram: any): void;
}
