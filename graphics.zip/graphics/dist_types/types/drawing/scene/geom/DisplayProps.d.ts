import { Shadow } from "../../Shadow";
import { Matrix2D } from "./Matrix2D";
import { float } from "@tuval/core";
/**
 * Used for calculating and encapsulating display related properties.
 * @memberof easeljs
 * @param {Number} [visible] Visible value.
 * @param {Number} [alpha] Alpha value.
 * @param {Number} [shadow] A Shadow instance or null.
 * @param {Number} [compositeOperation] A compositeOperation value or null.
 * @param {Number} [matrix] A transformation matrix. Defaults to a new identity matrix.
 */
export declare class DisplayProps {
    visible: boolean;
    alpha: number;
    shadow: Shadow;
    compositeOperation: string;
    matrix: Matrix2D;
    constructor(visible?: boolean, alpha?: number, shadow?: Shadow, compositeOperation?: string, matrix?: Matrix2D);
    /**
     * Reinitializes the instance with the specified values.
     * @param {Number} [visible=true] Visible value.
     * @param {Number} [alpha=1] Alpha value.
     * @param {Number} [shadow] A Shadow instance or null.
     * @param {Number} [compositeOperation] A compositeOperation value or null.
     * @param {Number} [matrix] A transformation matrix. Defaults to an identity matrix.
     * @return {easeljs.DisplayProps} This instance. Useful for chaining method calls.
     * @chainable
    */
    setValues(visible: boolean | undefined, alpha: number | undefined, shadow: Shadow, compositeOperation: string, matrix: Matrix2D): DisplayProps;
    /**
     * Appends the specified display properties. This is generally used to apply a child's properties its parent's.
     * @param {Boolean} visible desired visible value
     * @param {Number} alpha desired alpha value
     * @param {easeljs.Shadow} shadow desired shadow value
     * @param {String} compositeOperation desired composite operation value
     * @param {easeljs.Matrix2D} [matrix] a Matrix2D instance
     * @return {easeljs.DisplayProps} This instance. Useful for chaining method calls.
     * @chainable
    */
    append(visible: boolean, alpha: float, shadow: Shadow, compositeOperation: string, matrix: Matrix2D): DisplayProps;
    /**
     * Prepends the specified display properties. This is generally used to apply a parent's properties to a child's.
     * For example, to get the combined display properties that would be applied to a child, you could use:
     *
     * @example
     * let o = displayObject;
     * let props = new DisplayProps();
     * do {
     * 	 // prepend each parent's props in turn:
     * 	 props.prepend(o.visible, o.alpha, o.shadow, o.compositeOperation, o.getMatrix());
     * } while (o = o.parent);
     *
     * @param {Boolean} visible desired visible value
     * @param {Number} alpha desired alpha value
     * @param {easeljs.Shadow} shadow desired shadow value
     * @param {String} compositeOperation desired composite operation value
     * @param {easeljs.Matrix2D} [matrix] a Matrix2D instance
     * @return {easeljs.DisplayProps} This instance. Useful for chaining method calls.
     * @chainable
    */
    prepend(visible: boolean, alpha: float, shadow: Shadow, compositeOperation: string, matrix?: Matrix2D): DisplayProps;
    /**
     * Resets this instance and its matrix to default values.
     * @return {easeljs.DisplayProps} This instance. Useful for chaining method calls.
     * @chainable
    */
    identity(): DisplayProps;
    /**
     * Returns a clone of the DisplayProps instance. Clones the associated matrix.
     * @return {easeljs.DisplayProps} a clone of the DisplayProps instance.
     */
    clone(): DisplayProps;
}
