import { CGPoint } from '@tuval/cg';
import { float } from "@tuval/core";
/**
 * Represents an affine transformation matrix, and provides tools for constructing and concatenating matrices.
 *
 * <pre>
 * This matrix can be visualized as:
 *
 * 	[ a  c  tx
 * 	 b  d  ty
 * 	0  0  1  ]
 *
 * Note the locations of b and c.
 * </pre>
 *
 * @param {Number} [a] Specifies the a property for the new matrix.
 * @param {Number} [b] Specifies the b property for the new matrix.
 * @param {Number} [c] Specifies the c property for the new matrix.
 * @param {Number} [d] Specifies the d property for the new matrix.
 * @param {Number} [tx] Specifies the tx property for the new matrix.
 * @param {Number} [ty] Specifies the ty property for the new matrix.
 */
export declare class Matrix2D {
    a: number;
    b: number;
    c: number;
    d: number;
    tx: number;
    ty: number;
    /**
     * Multiplier for converting degrees to radians. Used internally by Matrix2D.
     * @static
     * @type {Number}
     * @readonly
     */
    static DEG_TO_RAD: number;
    /**
     * An identity matrix, representing a null transformation.
     * @static
     * @type {Matrix2D}
     * @readonly
     */
    static identity: Matrix2D;
    constructor(a?: float, b?: float, c?: float, d?: float, tx?: float, ty?: float);
    /**
     * Sets the specified values on this instance.
     * @param {Number} [a=1] Specifies the a property for the new matrix.
     * @param {Number} [b=0] Specifies the b property for the new matrix.
     * @param {Number} [c=0] Specifies the c property for the new matrix.
     * @param {Number} [d=1] Specifies the d property for the new matrix.
     * @param {Number} [tx=0] Specifies the tx property for the new matrix.
     * @param {Number} [ty=0] Specifies the ty property for the new matrix.
     * @return {Matrix2D} This instance. Useful for chaining method calls.
     * @chainable
    */
    setValues(a: float, b: float, c: float, d: float, tx: float, ty: float): this;
    /**
     * Appends the specified matrix properties to this matrix. All parameters are required.
     * This is the equivalent of multiplying `(this matrix) * (specified matrix)`.
     * @param {Number} a
     * @param {Number} b
     * @param {Number} c
     * @param {Number} d
     * @param {Number} tx
     * @param {Number} ty
     * @return {Matrix2D} This matrix. Useful for chaining method calls.
     * @chainable
     */
    append(a: float, b: float, c: float, d: float, tx: float, ty: float): this;
    /**
     * Prepends the specified matrix properties to this matrix.
     * This is the equivalent of multiplying `(specified matrix) * (this matrix)`.
     * @param {Number} a
     * @param {Number} b
     * @param {Number} c
     * @param {Number} d
     * @param {Number} tx
     * @param {Number} ty
     * @return {Matrix2D} This matrix. Useful for chaining method calls.
     * @chainable
     */
    prepend(a: float, b: float, c: float, d: float, tx: float, ty: float): this;
    /**
     * Appends the specified matrix to this matrix.
     * This is the equivalent of multiplying `(this matrix) * (specified matrix)`.
     * @param {Matrix2D} matrix
     * @return {Matrix2D} This matrix. Useful for chaining method calls.
     * @chainable
     */
    appendMatrix(matrix: Matrix2D): Matrix2D;
    /**
     * Prepends the specified matrix to this matrix.
     * This is the equivalent of multiplying `(specified matrix) * (this matrix)`.
     *
     * @example <caption>Calculate the combined transformation for a child object</caption>
     * let o = displayObject;
     * let mtx = o.getMatrix();
     * while (o = o.parent) {
     * 	 // prepend each parent's transformation in turn:
     * 	 o.prependMatrix(o.getMatrix());
     * }
     *
     * @param {Matrix2D} matrix
     * @return {Matrix2D} This matrix. Useful for chaining method calls.
     * @chainable
     */
    prependMatrix(matrix: Matrix2D): Matrix2D;
    /**
     * Generates matrix properties from the specified display object transform properties, and appends them to this matrix.
     *
     * @example <caption>Generate a matrix representing the transformations of a display object</caption>
     * let mtx = new Matrix2D();
     * mtx.appendTransform(o.x, o.y, o.scaleX, o.scaleY, o.rotation);
     *
     * @param {Number} x
     * @param {Number} y
     * @param {Number} scaleX
     * @param {Number} scaleY
     * @param {Number} rotation
     * @param {Number} skewX
     * @param {Number} skewY
     * @param {Number} [regX]
     * @param {Number} [regY]
     * @return {Matrix2D} This matrix. Useful for chaining method calls.
     * @chainable
     */
    appendTransform(x: float, y: float, scaleX: float, scaleY: float, rotation: float, skewX: float, skewY: float, regX: float, regY: float): Matrix2D;
    /**
     * Generates matrix properties from the specified display object transform properties, and prepends them to this matrix.
     *
     * Note that the above example would not account for {@link DisplayObject#transformMatrix} values.
     * See {@link Matrix2D#prependMatrix} for an example that does.
     *
     * @example <caption>Calculate the combined transformation for a child object</caption>
     * let o = displayObject;
     * let mtx = new Matrix2D();
     * do  {
     * 	 // prepend each parent's transformation in turn:
     * 	 mtx.prependTransform(o.x, o.y, o.scaleX, o.scaleY, o.rotation, o.skewX, o.skewY, o.regX, o.regY);
     * } while (o = o.parent);
     *
     * @param {Number} x
     * @param {Number} y
     * @param {Number} scaleX
     * @param {Number} scaleY
     * @param {Number} rotation
     * @param {Number} skewX
     * @param {Number} skewY
     * @param {Number} [regX]
     * @param {Number} [regY]
     * @return {Matrix2D} This matrix. Useful for chaining method calls.
     */
    prependTransform(x: float, y: float, scaleX: float, scaleY: float, rotation: float, skewX: float, skewY: float, regX: float, regY: float): Matrix2D;
    /**
     * Applies a clockwise rotation transformation to the matrix.
     * @param {Number} angle The angle to rotate by, in degrees. To use a value in radians, multiply it by `Math.PI/180`.
     * @return {Matrix2D} This matrix. Useful for chaining method calls.
     * @chainable
     */
    rotate(angle: float): Matrix2D;
    /**
     * Applies a skew transformation to the matrix.
     * @param {Number} skewX The amount to skew horizontally in degrees. To use a value in radians, multiply it by `Math.PI/180`.
     * @param {Number} skewY The amount to skew vertically in degrees.
     * @return {Matrix2D} This matrix. Useful for chaining method calls.
     * @chainable
    */
    skew(skewX: float, skewY: float): Matrix2D;
    /**
     * Applies a scale transformation to the matrix.
     * @param {Number} x The amount to scale horizontally. E.G. a value of 2 will double the size in the X direction, and 0.5 will halve it.
     * @param {Number} y The amount to scale vertically.
     * @return {Matrix2D} This matrix. Useful for chaining method calls.
     * @chainable
     */
    scale(x: float, y: float): Matrix2D;
    /**
     * Translates the matrix on the x and y axes.
     * @param {Number} x
     * @param {Number} y
     * @return {Matrix2D} This matrix. Useful for chaining method calls.
     * @chainable
     */
    translate(x: float, y: float): Matrix2D;
    /**
     * Sets the properties of the matrix to those of an identity matrix (one that applies a null transformation).
     * @return {Matrix2D} This matrix. Useful for chaining method calls.
     * @chainable
     */
    identity(): Matrix2D;
    /**
     * Inverts the matrix, causing it to perform the opposite transformation.
     * @return {Matrix2D} This matrix. Useful for chaining method calls.
     * @chainable
     */
    invert(): Matrix2D;
    /**
     * Returns true if the matrix is an identity matrix.
     * @return {Boolean}
     */
    isIdentity(): boolean;
    /**
     * Returns true if this matrix is equal to the specified matrix (all property values are equal).
     * @param {Matrix2D} matrix The matrix to compare.
     * @return {Boolean}
     */
    equals(matrix: Matrix2D): boolean;
    /**
     * Transforms a point according to this matrix.
     * @param {Number} x The x component of the point to transform.
     * @param {Number} y The y component of the point to transform.
     * @param {Point | Object} [pt] An object to copy the result into. If omitted a generic object with x/y properties will be returned.
     * @return {Point} This matrix. Useful for chaining method calls.
     */
    transformPoint(x: float, y: float, pt?: CGPoint): CGPoint;
    /**
     * Decomposes the matrix into transform properties (x, y, scaleX, scaleY, and rotation). Note that these values
     * may not match the transform properties you used to generate the matrix, though they will produce the same visual
     * results.
     * @param {Object} [target] The object to apply the transform properties to. If null, then a new object will be returned.
     * @return {Object} The target, or a new generic object with the transform properties applied.
    */
    decompose(target?: any): any;
    /**
     * Copies all properties from the specified matrix to this matrix.
     * @param {Matrix2D} matrix The matrix to copy properties from.
     * @return {Matrix2D} This matrix. Useful for chaining method calls.
     * @chainable
    */
    copy(matrix: Matrix2D): Matrix2D;
    /**
     * Returns a clone of the Matrix2D instance.
     * @return {Matrix2D} a clone of the Matrix2D instance.
     */
    clone(): Matrix2D;
    /**
     * Returns a string representation of this object.
     * @return {String} a string representation of the instance.
     */
    toString(): string;
}
