import { CGSize } from '@tuval/cg';
import { Event } from "@tuval/core";
import { Font } from "./Font";
import { StringFormat } from "./StringFormat";
import { SimpleDictionary } from "@tuval/core";
export declare class Entry {
    text: string;
    font: Font;
    layoutArea: CGSize;
    format: StringFormat;
    charactersFitted: number;
    linesFilled: number;
    measure: CGSize;
    constructor(text: string, font: Font, layoutArea: CGSize, format: StringFormat);
    conformsTo(text: string, font: Font, layoutArea: CGSize, format: StringFormat): boolean;
}
export declare class MeasureStringCache {
    protected lurch: SimpleDictionary<string, Entry>;
    protected enabled: boolean;
    private myCreateEntryDelegate;
    get CreateEntryDelegate(): Event<any>;
    set CreateEntryDelegate(value: Event<any>);
    MeasureStringCache(capacity: number, enabled?: boolean): void;
    constructor(capacity: number, enabled?: boolean);
    getKey(s: string, font: Font, layoutArea: CGSize, format: StringFormat): string;
    private getOrCreate;
}
