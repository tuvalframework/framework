import { UMP } from '@tuval/core';
import { ImageCodecInfo } from './imaging/ImageCodecInfo';
import { PropertyItem } from './imaging/PropertyItem';
export declare class GdipEncoderParameter extends UMP {
    guid: any;
    numberOfValues: any;
    type: any;
    value: any;
}
export declare class GdiplusStartupInput extends UMP {
    GdiplusVersion: any;
    DebugEventCallback: any;
    SuppressBackgroundThread: any;
    SuppressExternalCodecs: any;
    static MakeGdiplusStartupInput(): GdiplusStartupInput;
}
export declare class GdiplusStartupOutput extends UMP {
    NotificationHook: any;
    NotificationUnhook: any;
    static MakeGdiplusStartupOutput(): GdiplusStartupOutput;
}
export declare class GdipPropertyItem extends UMP {
    id: any;
    len: any;
    type: any;
    value: any;
    static MarshalTo(gdipProp: GdipPropertyItem, prop: PropertyItem): void;
}
export declare class GdipImageCodecInfo extends UMP {
    Clsid: any;
    FormatID: any;
    CodecName: any;
    DllName: any;
    FormatDescription: any;
    FilenameExtension: any;
    MimeType: any;
    Flags: any;
    Version: any;
    SigCount: any;
    SigSize: any;
    SigPattern: any;
    SigMask: any;
    static MarshalTo(gdipcodec: GdipImageCodecInfo, codec: ImageCodecInfo): void;
}
export declare class GdiColorPalette extends UMP {
    Flags: any;
    Count: any;
}
