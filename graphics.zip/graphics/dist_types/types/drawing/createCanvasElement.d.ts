export declare function createCanvasElement(): any;
export declare function get2DCanvasContext(canvas: HTMLCanvasElement): CanvasRenderingContext2D;
