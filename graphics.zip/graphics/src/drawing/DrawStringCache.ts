export class DrawStringCache {
    constructor(name: number) {

    }
}