export enum PenTypes {
    HatchFill = 0,
    LinearGradient = 1,
    PathGradient = 2,
    SolidColor = 3,
    TextureFill = 4,
    RadialGradient = 5,
    Custom = 6
}