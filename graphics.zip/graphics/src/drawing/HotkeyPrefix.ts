export enum HotkeyPrefix {
    None = 0,
    Show = 1,
    Hide = 2
}