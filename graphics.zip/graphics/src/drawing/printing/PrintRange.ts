export enum PrintRange {
    AllPages = 0,
    Selection = 1,
    SomePages = 2,
    CurrentPage = 4194304
}