
export class PageSettings {
    public PrinterSettings:any;
}