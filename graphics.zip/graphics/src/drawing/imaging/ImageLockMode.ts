export enum ImageLockMode {
    ReadOnly = 1,
    ReadWrite = 3,
    UserInputBuffer = 4,
    WriteOnly = 2
}