import { CGImage } from '@tuval/cg';
import { List } from "@tuval/core";

export class ImageList extends List<CGImage> {

}