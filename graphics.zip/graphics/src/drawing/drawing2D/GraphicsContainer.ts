    export class GraphicsContainer {
        private nativeGraphicsContainer: number;
        constructor(graphicsContainer: number) {
            this.nativeGraphicsContainer = graphicsContainer;
        }
    }