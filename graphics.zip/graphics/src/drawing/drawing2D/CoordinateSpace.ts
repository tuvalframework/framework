    export enum CoordinateSpace {
        World = 0,
        Page = 1,
        Device = 2
    }
