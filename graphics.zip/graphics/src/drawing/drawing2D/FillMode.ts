    export enum FillMode {
        Alternate = 0,
        Winding = 1
    }