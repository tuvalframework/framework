import { CGImage } from "@tuval/cg";

export class Icon {
    public toBitmap(): CGImage {
        return undefined as any;
    }
}