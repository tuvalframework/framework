export class StageGL {
	constructor (arg1, arg2) {
		throw new Error(`
			StageGL is not currently supported on the EaselJS 2.0 branch.
			End of Q1 2018 is targetted for StageGL support.
			Follow @CreateJS on Twitter for updates.
		`);
	}
}