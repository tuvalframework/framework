export enum HotkeyPrefix {
    None,
    Show,
    Hide
}