

export interface IMouseEventService {
    onMouseMove$: any;
    onMouseDown$: any;
    onMouseUp$: any;
}