import React, { useEffect, useState } from "react";
import { Fragment } from "react";
import { useInRouterContext, useParams } from "react-router-dom";
import { UIController, UIFormContext } from "../../UIController";


export interface IControlProperties {
    controllerType: new ()=> UIController;
}


function ControllerRenderer({ controllerType }: IControlProperties) {
    
    const inRouterContext = useInRouterContext();
    const routerParams = useParams();
    
    const [updateValue, setUpdateValue] = useState(0)
    const [propertyBag, setPropertyBag] = useState({})

    const controller = new controllerType();
    controller.propertyBag = propertyBag;
    controller.ForceUpdate = () => {
        alert('force')
        const value = updateValue + 1;
        setUpdateValue(value);

    }

    useEffect(()=> {
        if (inRouterContext) {
            controller.BindRouterParams(routerParams);
        }
        
    },[])

    return (
        <UIFormContext.Provider value={this}>
            {
               controller.LoadView().render()
            }
       </UIFormContext.Provider >
    );

}

export default ControllerRenderer;