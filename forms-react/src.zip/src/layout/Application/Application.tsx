import React, { createContext, useContext } from "react";
import { UIController } from "../../UIController";
import ControllerRenderer from "../Controller/ControllerRenderer";

export const ApplicationContext = createContext(null!);

export function useApplication(): Application {
    return useContext(ApplicationContext);
}

export interface IApplication {
    name: string;
    controller: new () => UIController;
}
export class Application extends React.Component<IApplication, any> {
    public get Name(): string {
        return this.props.name;
    }
    constructor(props) {
        super(props);
        this.state = {};
    }
    public render(): React.ReactNode {
        return (
            <ApplicationContext.Provider value={this}>
                <ControllerRenderer controllerType={this.props.controller}></ControllerRenderer>
            </ApplicationContext.Provider>
        )
    }
}