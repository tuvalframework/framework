import { int } from "@tuval/core";
import { AlignmentType } from "../../Constants";
import { UIView } from "../../components/UIView/UIView";
import { DesktopClass } from './DesktopClass';



/* export function VStack(value: string): FunctionVStack; */
export function Desktop(startPath?: string): DesktopClass {
    return new DesktopClass().startPath(startPath)
}