import React from "react";
import { DesktopController } from "../../DesktopController";
import ControllerRenderer from "../Controller/ControllerRenderer";
import { DesktopClass } from "./DesktopClass";



export interface IControlProperties {
    control: DesktopClass
}


function DesktopRenderer({ control }: IControlProperties) {
    return (
        <ControllerRenderer controllerType={DesktopController} />
    );
}

export default DesktopRenderer;