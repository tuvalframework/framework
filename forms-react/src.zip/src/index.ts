//export * from './main'
export * from './components'

export * from './components/UIView/UIView'
export * from './components/UIView/ForEach'

export * from './layout'


export * from './components/Text/Text'

export * from './components/Router/UIRoutes/UIRoutes'
export * from './components/Router/UIRoute/UIRoute'
export * from './components/Router/Outlet/UIRouteOutlet'
export * from './components/Router/UIRouteLink/UIRouteLink'
export * from './components/Router/Navigate'

export * from './components/List'
export * from './components/Fragment'

export * from './components/ReactView/ReactView'
export * from './components/ReactView/ReactViewClass'

export * from './DesktopController'

export * from './Color'
export * from './ColorClass'
export * from './ColorConverter'

export * from './components/Icon'

export * from './UITemplate'
export * from './Theme'

export * from './UIController'
export * from './Constants'

export * from './UIAppearance'

export * from './Bios'

//--------------------
export { useNavigate, useLocation, useParams } from 'react-router-dom'
export { useState , useEffect} from 'react'


//-------------------

export * from './data'

import './exports';
import { Navigate } from 'react-router-dom';


