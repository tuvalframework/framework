

//import './css/global.scss';

import 'primeicons/primeicons.css';
import 'primereact/resources/primereact.css';
import 'primereact/resources/themes/bootstrap4-light-blue/theme.css';

import 'primeflex/primeflex.css';

import 'monday-ui-react-core/dist/main.css';


/* import { StartBios } from './Bios';
import { LayoutController } from './LayoutController'; */

/* 
window.addEventListener("load", (event) => {
    StartBios(LayoutController);
});
 */