import { InputNumberClass } from "./InputNumberClass";

export function InputNumber() {
    return new InputNumberClass();
}