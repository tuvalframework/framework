import { MultiSelectClass } from "./MultiSelectClass";

export function MultiSelect() {
    return new MultiSelectClass();
}