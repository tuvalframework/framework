import { ChipsClass } from "./ChipsClass";

export function Chips() {
    return new ChipsClass();
}