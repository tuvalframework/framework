import { UIRadioGroupClass } from "./UIRadioGroupClass";

export function UIRadioGroup(): UIRadioGroupClass {
     
           return new UIRadioGroupClass();
     
     
  }