import { MentionClass } from "./MentionClass";

export function Mention() {
    return new MentionClass();
}