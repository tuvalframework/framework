import { KnobClass } from "./KnobClass";

export function Knob() {
    return new KnobClass();
}