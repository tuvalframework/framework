import { ListTitleClass } from "./ListTitleClass";

export function ListTitle() {
    return new ListTitleClass();
}