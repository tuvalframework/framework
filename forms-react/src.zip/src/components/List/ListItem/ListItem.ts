import { ListItemClass } from "./ListItemClass";

export function ListItem() {
    return new ListItemClass();
}