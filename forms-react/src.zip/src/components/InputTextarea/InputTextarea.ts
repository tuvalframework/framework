import { InputTextareaClass } from "./InputTextareaClass";

export function InputTextArea() {
    return new InputTextareaClass();
}