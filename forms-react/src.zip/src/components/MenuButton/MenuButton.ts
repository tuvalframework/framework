import { MenuButtonClass } from "./MenuButtonClass";

export function MenuButton() {
    return new MenuButtonClass();
}