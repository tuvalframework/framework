import { EditorClass } from "./EditorClass";

export function Editor() {
    return new EditorClass();
}