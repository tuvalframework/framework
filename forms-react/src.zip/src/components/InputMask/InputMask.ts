import {  InputMaskClass } from "./InputMaskClass";

export function InputMask() {
    return new InputMaskClass();
}