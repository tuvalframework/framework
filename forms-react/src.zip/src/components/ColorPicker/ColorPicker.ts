import { ColorPickerClass } from "./ColorPickerClass";

export function ColorPicker() {
    return new ColorPickerClass();
}