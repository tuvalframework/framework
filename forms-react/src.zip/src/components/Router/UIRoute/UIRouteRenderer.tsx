import React from "react";
import { Link, Route, Routes } from "react-router-dom";
import ControllerRenderer from "../../../layout/Controller/ControllerRenderer";
import { UIView } from "../../UIView/UIView";
import { UIRouteClass } from "./UIRouteClass";

export interface IControlProperties {
    control: UIRouteClass
}


function UIRouteRenderer({ control }: IControlProperties) {
    if (control.vp_IsIndex) {
        return (
            <Route index element={<ControllerRenderer controllerType={control.vp_RouteController}></ControllerRenderer>}></Route>
        )
    } else {
        return (
            <Route path={control.vp_RoutePath} element={<ControllerRenderer controllerType={control.vp_RouteController}></ControllerRenderer>}>
                {
                    control.vp_Chidren.map((view: UIView) => view.render())
                }
            </Route>
        )
    }
}

export default UIRouteRenderer;