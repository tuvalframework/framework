import { UIRouteOutletClass } from "./UIRouteOutletClass";

export function UIRouteOutlet(): UIRouteOutletClass {
    return new UIRouteOutletClass();
}