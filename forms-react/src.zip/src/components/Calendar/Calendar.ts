import { CalendarClass } from "./CalendarClass";

export function Calendar() {
    return new CalendarClass();
}