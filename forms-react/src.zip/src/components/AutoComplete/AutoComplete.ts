import { AutoCompleteClass } from "./AutoCompleteClass";



export function AutoComplete() {
    return new AutoCompleteClass();
}