import { ListBoxClass } from "./ListBoxClass";



export function ListBox() {
    return new ListBoxClass();
}