import { InputSwitchClass } from "./InputSwitchClass";

export function InputSwitch() {
    return new InputSwitchClass();
}