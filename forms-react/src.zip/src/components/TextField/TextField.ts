import { TextFieldClass } from "./TextFieldClass";


export function TextField() {
    return new TextFieldClass();
}