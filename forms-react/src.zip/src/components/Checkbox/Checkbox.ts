import { CheckBoxClass } from "./CheckboxClass";



export function CheckBox() {
    return new CheckBoxClass();
}