import { InputGroupClass } from "./InputGroupClass";

export function InputGroup() {
    return new InputGroupClass();
}